from tkinter import *
from tkinter import messagebox

window = Tk()
window.title("Quản Lí Chim Trong Rừng")
window.geometry("500x550")

editing_index = None

def them_chim():
  
    if editing_index is not None:
        messagebox.showwarning("Cảnh báo", "Bạn đang ở chế độ sửa! Vui lòng lưu hoặc hủy trước.")
        return

    ten = entry_ten.get().strip()
    loai = entry_loai.get().strip()

    if ten != "" and loai != "":
        ten_chuan = ten.capitalize()   
        loai_chuan = loai.title()      
        
        listbox.insert(END, f"{ten_chuan} - {loai_chuan}")

        entry_ten.delete(0, END)
        entry_loai.delete(0, END)
    else:
        messagebox.showwarning("Cảnh báo", "Vui lòng nhập đầy đủ cả Tên chim và Loài chim!")

def xoa_chim():
    selected = listbox.curselection()
    if selected:
        listbox.delete(selected)

        cancel_edit()
    else:
        messagebox.showwarning("Thông báo", "Vui lòng chọn một chú chim để xóa!")

def sua_chim():
    global editing_index
    
    if editing_index is None:
        selected = listbox.curselection()
        if not selected:
            messagebox.showwarning("Thông báo", "Vui lòng chọn một chú chim trong danh sách cần sửa!")
            return
        
        editing_index = selected[0]
        
        current_text = listbox.get(editing_index)
        
       
        parts = current_text.split(" - ")
        ten_cu = parts[0]
        loai_cu = parts[1] if len(parts) > 1 else ""
      
        entry_ten.delete(0, END)
        entry_ten.insert(0, ten_cu)
        entry_loai.delete(0, END)
        entry_loai.insert(0, loai_cu)
        
      
        btn_sua.config(text="Lưu Thay Đổi", bg="#4CAF50", fg="white")
        btn_huy.pack(pady=5)

    else:
        ten_moi = entry_ten.get().strip()
        loai_moi = entry_loai.get().strip()
        
        if ten_moi != "" and loai_moi != "":
          
            listbox.delete(editing_index)
            listbox.insert(editing_index, f"{ten_moi.capitalize()} - {loai_moi.title()}")
            
            cancel_edit()
            messagebox.showinfo("Thành công", "Đã cập nhật thông tin thành công!")
        else:
            messagebox.showwarning("Cảnh báo", "Không được để trống Tên hoặc Loài chim!")

def cancel_edit():
    """Hàm bổ trợ dùng để hủy trạng thái sửa, xóa chữ ở ô nhập liệu"""
    global editing_index
    editing_index = None
    entry_ten.delete(0, END)
    entry_loai.delete(0, END)
    btn_sua.config(text="Sửa Chim", bg=window.cget('bg'), fg="black") 
    btn_huy.pack_forget()

label_title = Label(window, text="QUẢN LÍ CHIM TRONG RỪNG", font=("Arial", 18))
label_title.pack(pady=10)

label_ten = Label(window, text="Tên chim:")
label_ten.pack()

entry_ten = Entry(window, width=30)
entry_ten.pack()

label_loai = Label(window, text="Loài chim:")
label_loai.pack()

entry_loai = Entry(window, width=30)
entry_loai.pack()

btn_them = Button(window, text="Thêm Chim", command=them_chim, width=15)
btn_them.pack(pady=5)

btn_sua = Button(window, text="Sửa Chim", command=sua_chim, width=15)
btn_sua.pack(pady=5)

btn_huy = Button(window, text="Hủy Sửa", command=cancel_edit, width=15, bg="#f44336", fg="white")

btn_xoa = Button(window, text="Xóa Chim", command=xoa_chim, width=15)
btn_xoa.pack(pady=5)

listbox = Listbox(window, width=50, height=12)
listbox.pack(pady=10)

window.mainloop()/Users/leminhhoang/danh.py