import json
import os
import tkinter as tk
import tkinter.ttk as ttk
from tkinter import filedialog, messagebox
import ttkbootstrap as tttk

BASE_PATH = os.path.dirname(__file__)
DATA_FILE = os.path.join(BASE_PATH, 'students.json')

window = tttk.Window("Student Manager", size=(900, 600), position=(100, 100))

st_list = []

def load_data():
    global st_list
    try:
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            st_list = json.load(f)
    except Exception:
        st_list = [{"Name": "Messi", "Age": 50, "Job": "Janitor"}]

def save_data():
    try:
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(st_list, f, indent=2, ensure_ascii=False)
    except Exception as e:
        messagebox.showwarning('Save failed', str(e))

def refresh_table(filter_text=''):
    for r in tree.get_children():
        tree.delete(r)
    for st in st_list:
        if filter_text and filter_text.lower() not in st.get('Name','').lower():
            continue
        tree.insert('', 'end', values=(st.get('Name'), st.get('Age'), st.get('Job')))
    update_stats()

def update_stats():
    count = len(st_list)
    ages = [s.get('Age') for s in st_list if isinstance(s.get('Age'), int)]
    avg = round(sum(ages)/len(ages),1) if ages else 'N/A'
    stats_lbl.config(text=f'Count: {count}    Avg age: {avg}')

def add_student_dialog(event=None, prefill=None, item_id=None):
    dg = tk.Toplevel(window)
    dg.title('Add / Edit Student')
    dg.transient(window)
    dg.grab_set()

    ttk.Label(dg, text='Name:').grid(row=0, column=0, padx=6, pady=6, sticky='e')
    ttk.Label(dg, text='Age:').grid(row=1, column=0, padx=6, pady=6, sticky='e')
    ttk.Label(dg, text='Job:').grid(row=2, column=0, padx=6, pady=6, sticky='e')

    name_var = tk.StringVar(value=(prefill.get('Name') if prefill else ''))
    age_var = tk.StringVar(value=(str(prefill.get('Age')) if prefill else ''))
    job_var = tk.StringVar(value=(prefill.get('Job') if prefill else ''))

    e_name = ttk.Entry(dg, textvariable=name_var, width=30)
    e_age = ttk.Entry(dg, textvariable=age_var, width=10)
    e_job = ttk.Entry(dg, textvariable=job_var, width=30)

    e_name.grid(row=0, column=1, padx=6, pady=6)
    e_age.grid(row=1, column=1, padx=6, pady=6)
    e_job.grid(row=2, column=1, padx=6, pady=6)

    def submit():
        name = name_var.get().strip()
        age = age_var.get().strip()
        job = job_var.get().strip() or 'N/A'
        if not name:
            messagebox.showerror('Invalid', 'Name cannot be empty.', parent=dg)
            return
        try:
            age_i = int(age)
        except ValueError:
            messagebox.showerror('Invalid', 'Age must be an integer.', parent=dg)
            return
        nl_item = None
        if prefill and item_id is not None:
            idx = tree.index(item_id)
            st_list[idx] = {'Name': name.title(), 'Age': age_i, 'Job': job}
        else:
            st_list.append({'Name': name.title(), 'Age': age_i, 'Job': job})
        refresh_table(search_var.get())
        save_data()
        dg.destroy()

    submit_btn = tttk.Button(dg, text='Save', command=submit)
    submit_btn.grid(row=3, column=0, columnspan=2, pady=8)
    e_name.focus()

def get_selected_item():
    sel = tree.selection()
    if not sel:
        return None
    return sel[0]

def edit_selected(event=None):
    item = get_selected_item()
    if not item:
        messagebox.showinfo('Select', 'Select a student to edit.')
        return
    vals = tree.item(item, 'values')
    prefill = {'Name': vals[0], 'Age': int(vals[1]), 'Job': vals[2]}
    add_student_dialog(prefill=prefill, item_id=item)

def delete_selected(event=None):
    item = get_selected_item()
    if not item:
        messagebox.showinfo('Select', 'Select a student to delete.')
        return
    vals = tree.item(item, 'values')
    name = vals[0]
    if not messagebox.askyesno('Confirm', f'Delete {name}?'):
        return
    # find and remove first matching
    for i, s in enumerate(st_list):
        if s.get('Name') == name and str(s.get('Age')) == str(vals[1]):
            del st_list[i]
            break
    refresh_table(search_var.get())
    save_data()

def export_json():
    path = filedialog.asksaveasfilename(defaultextension='.json', filetypes=[('JSON', '*.json')])
    if not path:
        return
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(st_list, f, indent=2, ensure_ascii=False)
        messagebox.showinfo('Export', 'Export successful.')
    except Exception as e:
        messagebox.showerror('Export failed', str(e))

def import_json():
    path = filedialog.askopenfilename(filetypes=[('JSON', '*.json')])
    if not path:
        return
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if isinstance(data, list):
            st_list.clear()
            for it in data:
                st_list.append(it)
            refresh_table()
            save_data()
            messagebox.showinfo('Import', 'Import successful.')
    except Exception as e:
        messagebox.showerror('Import failed', str(e))

def on_search(*args):
    refresh_table(search_var.get())

def tree_sort_column(col, reverse=False):
    data = [(tree.set(k, col), k) for k in tree.get_children('')]
    # convert ages to int when sorting Age
    if col == 'Age':
        data = [((int(v) if v.isdigit() else v), k) for v, k in data]
    data.sort(reverse=reverse, key=lambda t: t[0])
    for index, (_, k) in enumerate(data):
        tree.move(k, '', index)
    # reverse sort next time
    tree.heading(col, command=lambda: tree_sort_column(col, not reverse))

load_data()

# --- UI ---
top = ttk.Frame(window)
top.pack(fill='x', padx=12, pady=8)

search_var = tk.StringVar()
ttk.Label(top, text='Search:').pack(side='left')
search_entry = ttk.Entry(top, textvariable=search_var)
search_entry.pack(side='left', padx=6)
search_var.trace_add('write', on_search)

ttk.Button(top, text='Add', command=add_student_dialog).pack(side='left', padx=6)
ttk.Button(top, text='Edit', command=edit_selected).pack(side='left')
ttk.Button(top, text='Delete', command=delete_selected).pack(side='left', padx=6)
ttk.Button(top, text='Import', command=import_json).pack(side='left')
ttk.Button(top, text='Export', command=export_json).pack(side='left', padx=6)

stats_lbl = ttk.Label(window, text='')
stats_lbl.pack(anchor='e', padx=12)

cols = ('Name', 'Age', 'Job')
tree = ttk.Treeview(window, columns=cols, show='headings', height=15)
for c in cols:
    tree.heading(c, text=c, command=lambda _c=c: tree_sort_column(_c))
    tree.column(c, anchor='center')
tree.pack(fill='both', expand=True, padx=12, pady=8)

def on_right_click(event):
    iid = tree.identify_row(event.y)
    if iid:
        tree.selection_set(iid)
        menu.tk_popup(event.x_root, event.y_root)

menu = tk.Menu(window, tearoff=0)
menu.add_command(label='Edit', command=edit_selected)
menu.add_command(label='Delete', command=delete_selected)

tree.bind('<Button-3>', on_right_click)
tree.bind('<Double-1>', edit_selected)
window.bind('<Delete>', delete_selected)
window.bind('<Control-n>', lambda e: add_student_dialog())
window.bind('<Control-s>', lambda e: export_json())

refresh_table()

window.protocol('WM_DELETE_WINDOW', lambda: (save_data(), window.destroy()))

window.mainloop()