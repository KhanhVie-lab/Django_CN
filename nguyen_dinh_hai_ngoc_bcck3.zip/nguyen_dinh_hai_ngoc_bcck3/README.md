# Product Manager v1.000

### Đây là ứng dụng quản lý chi phí nhập hàng, xuất hàng

### Một số tính năng nổi bật của ứng dụng:
- Nhập, chỉnh sửa, xuất một hoặc nhiều mặt hàng
- Tự động cập nhật, cảnh báo ngân sách
- Quản lý được nhiều danh sách sản phẩm
- Tìm kiếm, lọc danh sách, sản phẩm nhanh chóng

### Giao diện ứng dụng
![Screenshot 2026-06-28 104529.png](pictures/Screenshot%202026-06-28%20104529.png)

![Screenshot 2026-06-28 104711.png](pictures/Screenshot%202026-06-28%20104711.png)

![Screenshot 2026-06-28 104743.png](pictures/Screenshot%202026-06-28%20104743.png)

![Screenshot 2026-06-28 104756.png](pictures/Screenshot%202026-06-28%20104756.png)

![Screenshot 2026-06-28 104841.png](pictures/Screenshot%202026-06-28%20104841.png)

![Screenshot 2026-06-28 104851.png](pictures/Screenshot%202026-06-28%20104851.png)
(hướng dẫn sử dụng "chi tiết" nằm ở đây)

![Screenshot 2026-06-28 104917.png](pictures/Screenshot%202026-06-28%20104917.png)

![Screenshot 2026-06-28 105229.png](pictures/Screenshot%202026-06-28%20105229.png)

![Screenshot 2026-06-28 105238.png](pictures/Screenshot%202026-06-28%20105238.png)

![Screenshot 2026-06-28 105247.png](pictures/Screenshot%202026-06-28%20105247.png)