from functions.CONFIG import *

config = load_config()

class AppState:
    current_editing_file = None if config["default_list"] is None else Path("data")/(config["default_list"]+".db")