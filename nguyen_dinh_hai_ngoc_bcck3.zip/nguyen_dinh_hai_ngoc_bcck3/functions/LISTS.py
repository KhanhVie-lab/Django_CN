from functions.CONFIG import *
from data.state import *

def is_valid(file_name):
    for c in file_name:
        if not (c.isalpha() or c.isdigit() or c == "_"): return False
    return True

def checking_data_folder():
    data_folder = Path("data")
    if not data_folder.exists():
        data_folder.mkdir(parents=True, exist_ok=True)
    return data_folder

def get_last_modified_date(file_path):
    path_obj = Path(file_path)
    if path_obj.exists():
        timestamp = path_obj.stat().st_mtime
        dt_object = datetime.fromtimestamp(timestamp)
        return dt_object.strftime("%d/%m/%Y %H:%M:%S")
    return None

def check_financial_feasibility(target_file_path, total_cost):
    config = load_config()
    master_budget = config.get("master_budget", 0.0)
    master_threshold = config.get("master_threshold", 0.0)

    total_lists_budget = 0.0
    data_folder = Path("data")
    current_list_budget = 0.0
    list_threshold = 0.0

    if data_folder.exists():
        for db_file in data_folder.glob("*.db"):
            try:
                with sqlite3.connect(db_file) as conn:
                    cursor = conn.cursor()
                    cursor.execute("SELECT count(name) FROM sqlite_master WHERE type='table' AND name='list_info'")
                    if cursor.fetchone()[0] == 1:
                        cursor.execute("SELECT budget, min_threshold FROM list_info")
                        res = cursor.fetchone()
                        if res:
                            total_lists_budget += res[0]
                            if db_file.resolve() == Path(target_file_path).resolve():
                                current_list_budget = res[0]
                                list_threshold = res[1]
            except Exception:
                pass
    global_budget = master_budget + total_lists_budget
    if total_cost <= 0:
        return True
    if master_budget < master_threshold:
        messagebox.showerror(
            "Financial Error: Master Threshold Violated",
            f"Transaction Denied!\n"
            f"Master Budget is currently below the required safety threshold.\n\n"
            f"Current Master Budget: ${master_budget:,.2f}\n"
            f"Required Master Threshold: ${master_threshold:,.2f}"
        )
        return False
    if global_budget - total_cost < 0:
        messagebox.showerror(
            "Financial Error: Global Budget Deficit",
            f"Transaction Denied!\n"
            f"The total system budget is insufficient to cover this transaction.\n\n"
            f"Global Budget Available: ${global_budget:,.2f}\n"
            f"Required Transaction Cost: ${total_cost:,.2f}\n"
            f"Deficit Amount: ${(total_cost - global_budget):,.2f}"
        )
        return False
    if current_list_budget - total_cost < list_threshold:
        subsidized_amount = list_threshold - (current_list_budget - total_cost)
        confirm = messagebox.askyesno(
            "Financial Warning: List Budget Alert",
            f"The active list budget will drop below its safety threshold.\n"
            f"However, the Master Budget has sufficient funds to subsidize this operation.\n\n"
            f"Current List Budget: ${current_list_budget:,.2f}\n"
            f"List Safety Threshold: ${list_threshold:,.2f}\n"
            f"Required Compensation from Master: ${subsidized_amount:,.2f}\n\n"
            f"Do you want to proceed and allow Master Budget to compensate?"
        )
        if confirm:
            # ĐÃ SỬA: Thực thi chuyển tiền bù trừ ngay lập tức
            config["master_budget"] -= subsidized_amount
            with open("config.json", "w", encoding="utf-8") as f:
                json.dump(config, f, indent=4)
            try:
                with sqlite3.connect(target_file_path) as conn:
                    conn.execute("UPDATE list_info SET budget = budget + ?", (subsidized_amount,))
            except Exception as e:
                print(f"Error updating subsidized amount: {e}")
            return True
        else:
            return False
    return True

###################################################################################################################
def import_product_window(root, main_tree_refresh):
    if AppState.current_editing_file is None:
        messagebox.showerror("Error", "No list is currently being edited!")
        return
    config = load_config()
    font_size = config["font_size"]
    font_type = config["font_type"]

    data_folder = checking_data_folder()
    file_path = Path(AppState.current_editing_file)

    misc_list_config = config.get("misc_list", {})
    headings_dict = misc_list_config.get("headings", {})
    widths_dict = misc_list_config.get("widths", {})
    field_keys = ["name", "origin", "date", "count", "import_price", "export_price"]

    window = ttk.Toplevel(master=root, title="Import Product Window", size=(720, 640))
    window.grab_set()

    container_frame = ttk.Frame(window)
    container_frame.pack(side="top", fill="both", expand=True, padx=15, pady=15)
    canvas = tk.Canvas(container_frame, highlightthickness=0, bd=0)
    scrollbar_y = ttk.Scrollbar(container_frame, orient="vertical", command=canvas.yview)
    scrollbar_x = ttk.Scrollbar(container_frame, orient="horizontal", command=canvas.xview)
    canvas.configure(yscrollcommand=scrollbar_y.set, xscrollcommand=scrollbar_x.set)
    scrollbar_y.pack(side="right", fill="y")
    scrollbar_x.pack(side="bottom", fill="x")
    canvas.pack(side="left", fill="both", expand=True)
    inner_frame = ttk.Frame(canvas)
    canvas.create_window((0, 0), window=inner_frame, anchor="nw")
    inner_frame.columnconfigure(0, minsize=45)

    for i, key in enumerate(field_keys):
        col_width = widths_dict.get(key, 150)
        inner_frame.columnconfigure(i + 1, minsize=col_width)

    lbl_del = ttk.Label(inner_frame, text="Act", anchor="center", font=(font_type, font_size, "bold"))
    lbl_del.grid(row=0, column=0, sticky="ew", padx=2, pady=8)

    for i, key in enumerate(field_keys):
        header_text = headings_dict.get(key, key.capitalize())
        lbl = ttk.Label(inner_frame, text=header_text, anchor="center", font=(font_type, font_size, "bold"))
        lbl.grid(row=0, column=i + 1, sticky="ew", padx=2, pady=8)

    def on_frame_configure(event):
        bbox = canvas.bbox("all")
        if bbox: canvas.configure(scrollregion=(0, 0, bbox[2], bbox[3]))

    def _on_mousewheel(event):
        if canvas.winfo_exists() and canvas.bbox("all")[3] > canvas.winfo_height():
            canvas.yview_scroll(int(-1 * (event.delta / 120) * 2), "units")

    def _on_shift_mousewheel(event):
        if canvas.winfo_exists() and canvas.bbox("all")[2] > canvas.winfo_width():
            canvas.xview_scroll(int(-1 * (event.delta / 120) * 2), "units")

    inner_frame.bind("<Configure>", on_frame_configure)
    canvas.bind("<Enter>", lambda e: (canvas.bind_all("<MouseWheel>", _on_mousewheel),
                                      canvas.bind_all("<Shift-MouseWheel>", _on_shift_mousewheel)))
    canvas.bind("<Leave>", lambda e: (canvas.unbind_all("<MouseWheel>"), canvas.unbind_all("<Shift-MouseWheel>")))
    window.bind("<Destroy>", lambda e: (canvas.unbind_all("<MouseWheel>"), canvas.unbind_all("<Shift-MouseWheel>")))

    all_rows_data = []
    row_counter = 1

    def add_row():
        nonlocal row_counter
        current_row_idx = row_counter
        row_counter += 1
        row_vars = {key: tk.StringVar() for key in field_keys}
        row_widgets = []
        row_entry_data = {"vars": row_vars, "widgets": row_widgets}
        all_rows_data.append(row_entry_data)

        del_btn = ttk.Button(inner_frame, text="X", bootstyle="danger-outline", width=3)
        del_btn.grid(row=current_row_idx, column=0, padx=4, pady=4)
        row_widgets.append(del_btn)

        def delete_this_row(data_to_remove=row_entry_data):
            for widget in data_to_remove["widgets"]: widget.destroy()
            all_rows_data.remove(data_to_remove)
            canvas.update_idletasks()
            canvas.configure(scrollregion=canvas.bbox("all"))

        del_btn.configure(command=delete_this_row)

        for i, key in enumerate(field_keys):
            entry = ttk.Entry(inner_frame, textvariable=row_vars[key])
            entry.grid(row=current_row_idx, column=i + 1, sticky="ew", pady=4, padx=2)
            row_widgets.append(entry)

        canvas.update_idletasks()
        bbox = canvas.bbox("all")
        if bbox:
            canvas.configure(scrollregion=(0, 0, bbox[2], bbox[3]))
            if bbox[3] > canvas.winfo_height(): canvas.yview_moveto(1.0)

    def save_all():
        total_cost = 0
        current_time = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        products_to_import = []
        summary_changes = []
        for index, row in enumerate(all_rows_data, start=1):
            name = row["vars"]["name"].get().strip()
            if not name: continue
            origin = row["vars"]["origin"].get().strip()
            date = row["vars"]["date"].get().strip()
            try:
                if " " not in date:
                    parsed_date = datetime.strptime(date, "%d/%m/%Y")
                    date = parsed_date.strftime("%d/%m/%Y 00:00:00")
                else:
                    parsed_date = datetime.strptime(date, "%d/%m/%Y %H:%M:%S")
                    date = parsed_date.strftime("%d/%m/%Y %H:%M:%S")
            except ValueError:
                messagebox.showerror(
                    "❗Error❗",
                    f"Invalid date format in row {index}!\n\n"
                    f"Your input: '{date}'\n"
                    f"Expected format: dd/mm/YYYY (31/12/2026)\n"
                    f"Or: dd/mm/YYYY HH:MM:SS"
                )
                return
            try:
                count = int(row["vars"]["count"].get().strip()) if row["vars"]["count"].get().strip() else 0
                import_price = float(row["vars"]["import_price"].get().strip()) if row["vars"][
                    "import_price"].get().strip() else 0.0
                export_price = float(row["vars"]["export_price"].get().strip()) if row["vars"][
                    "export_price"].get().strip() else 0.0
            except ValueError:
                messagebox.showerror("❗Error❗", f"Invalid count (int) or price (float) in row {index}!")
                return

            prod_id = str(uuid.uuid4())[:8].upper() + str(uuid.uuid4())[:8].upper()
            products_to_import.append((prod_id, name, origin, date, count, import_price, export_price, current_time))
            total_cost += (count * import_price)
            summary_changes.append(f"Row {index} (ID: {prod_id}) - Cost: ${count * import_price:,.2f}")

        if not products_to_import:
            messagebox.showinfo("Notification", "No valid data to save.")
            return
        try:
            conn = sqlite3.connect(file_path)
            cursor = conn.cursor()
            cursor.execute("SELECT budget FROM list_info")
            current_budget = cursor.fetchone()[0]
            confirm_msg = "Are you sure you want to import the following products?\n\n" + "\n".join(
                summary_changes[:10])
            if len(summary_changes) > 10:
                confirm_msg += f"\n... {len(summary_changes) - 10} more products."
            confirm_msg += f"\n\nTotal Import Cost: ${total_cost:,.2f}\nList Budget Change: ${current_budget:,.2f} -> ${(current_budget - total_cost):,.2f}"
            if not messagebox.askyesno("Confirmation", confirm_msg):
                return
            if not check_financial_feasibility(file_path, total_cost):
                return
            cursor.executemany('''
                INSERT INTO products (id, name, origin, date, count, import_price, export_price, last_update)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', products_to_import)
            cursor.execute("UPDATE list_info SET budget = budget - ?", (total_cost,))
            cursor.execute("DELETE FROM products WHERE count <= 0")  # Tự động xóa sản phẩm <= 0
            conn.commit()
            conn.close()
            main_tree_refresh()
            window.destroy()
            messagebox.showinfo("Success", "Products imported successfully!")
        except Exception as ERROR:
            messagebox.showerror("❗Error❗", f"Could not save data: {ERROR}")

    btn_frame = ttk.Frame(window)
    btn_frame.pack(side="bottom", pady=20)
    ttk.Button(btn_frame, text="ADD ROW", bootstyle="outline-primary", command=add_row).pack(side="left", padx=10)
    ttk.Button(btn_frame, text="IMPORT", bootstyle="success", command=save_all).pack(side="left", padx=10)


###################################################################################################################
def update_product_window(root, main_tree_refresh):
    if AppState.current_editing_file is None:
        messagebox.showerror("Error", "No list is currently being edited!")
        return
    config = load_config()
    font_size = config.get("font_size", 14)
    font_type = config.get("font_type", "Arial")
    file_path = Path(AppState.current_editing_file)

    prod_list_config = config.get("product_list", {})
    headings_dict = prod_list_config.get("headings", {})
    widths_dict = prod_list_config.get("widths", {})

    all_keys = ["id", "name", "origin", "date", "count", "import_price", "export_price", "last_update"]
    editable_keys = ["name", "origin", "date", "count", "import_price", "export_price"]

    try:
        with sqlite3.connect(file_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, name, origin, date, count, import_price, export_price, last_update FROM products")
            prods = cursor.fetchall()
    except Exception as e:
        messagebox.showerror("❗Error❗", f"Could not read data: {e}")
        return
    if not prods:
        messagebox.showinfo("Notification", "The list is currently empty. Nothing to update.")
        return

    window = ttk.Toplevel(master=root, title="Update Product Window", size=(760, 640))
    window.grab_set()

    filter_frame = ttk.LabelFrame(window)
    filter_frame.pack(side="top", fill="both", padx=15, pady=5)

    ttk.Label(filter_frame, text="Search:").pack(side="left", padx=5)
    search_var = tk.StringVar()
    search_entry = ttk.Entry(filter_frame, textvariable=search_var, width=20)
    search_entry.pack(side="left", fill='x', expand=True)

    sort_var = tk.StringVar()
    sort_options = [
        "Default", "Name (A-Z)", "Name (Z-A)", "Count (Low ➔ High)", "Count (High ➔ Low)",
        "Import Price (Low ➔ High)", "Import Price (High ➔ Low)",
        "Export Price (Low ➔ High)", "Export Price (High ➔ Low)",
        "Date (Oldest ➔ Newest)", "Date (Newest ➔ Oldest)",
        "Last Update (Oldest ➔ Newest)", "Last Update (Newest ➔ Oldest)"
    ]
    sort_combo = ttk.Combobox(filter_frame, textvariable=sort_var, values=sort_options, state="readonly", width=18)
    sort_combo.current(0)
    sort_combo.pack(side="right", padx=5)
    ttk.Label(filter_frame, text="Sort by:").pack(side="right", padx=5)

    filter_col_var = tk.StringVar()
    filter_options = [headings_dict.get(k, k.capitalize()) for k in all_keys]
    filter_combo = ttk.Combobox(filter_frame, textvariable=filter_col_var, values=filter_options, state="readonly", width=12)
    filter_combo.current(1)
    filter_combo.pack(side="right", padx=5)
    ttk.Label(filter_frame, text="Filter by:").pack(side="right", padx=5)

    container_frame = ttk.Frame(window)
    container_frame.pack(side="top", fill="both", expand=True, padx=15, pady=15)
    canvas = tk.Canvas(container_frame, highlightthickness=0, bd=0)
    scrollbar_y = ttk.Scrollbar(container_frame, orient="vertical", command=canvas.yview)
    scrollbar_x = ttk.Scrollbar(container_frame, orient="horizontal", command=canvas.xview)
    canvas.configure(yscrollcommand=scrollbar_y.set, xscrollcommand=scrollbar_x.set)
    scrollbar_y.pack(side="right", fill="y")
    scrollbar_x.pack(side="bottom", fill="x")
    canvas.pack(side="left", fill="both", expand=True)
    inner_frame = ttk.Frame(canvas)
    canvas.create_window((0, 0), window=inner_frame, anchor="nw")

    for i, key in enumerate(all_keys):
        inner_frame.columnconfigure(i, minsize=widths_dict.get(key, 120))

    for i, key in enumerate(all_keys):
        header_text = headings_dict.get(key, key.capitalize())
        lbl = ttk.Label(inner_frame, text=header_text, anchor="center", font=(font_type, font_size, "bold"))
        lbl.grid(row=0, column=i, sticky="ew", padx=2, pady=8)

    def on_frame_configure(event):
        canvas.configure(scrollregion=canvas.bbox("all"))

    def _on_mousewheel(event):
        if canvas.winfo_exists() and canvas.bbox("all")[3] > canvas.winfo_height(): canvas.yview_scroll(
            int(-1 * (event.delta / 120) * 2), "units")

    def _on_shift_mousewheel(event):
        if canvas.winfo_exists() and canvas.bbox("all")[2] > canvas.winfo_width(): canvas.xview_scroll(
            int(-1 * (event.delta / 120) * 2), "units")

    inner_frame.bind("<Configure>", on_frame_configure)
    canvas.bind("<Enter>", lambda e: (canvas.bind_all("<MouseWheel>", _on_mousewheel), canvas.bind_all("<Shift-MouseWheel>", _on_shift_mousewheel)))
    canvas.bind("<Leave>", lambda e: (canvas.unbind_all("<MouseWheel>"), canvas.unbind_all("<Shift-MouseWheel>")))
    window.bind("<Destroy>", lambda e: (canvas.unbind_all("<MouseWheel>"), canvas.unbind_all("<Shift-MouseWheel>")))

    all_rows_data = []
    for row_idx, prod in enumerate(prods, start=1):
        row_data = {}
        for col_idx, key in enumerate(all_keys):
            val = prod[col_idx]
            if key in editable_keys:
                var = tk.StringVar(value=str(val))
                entry = ttk.Entry(inner_frame, textvariable=var)
                entry.grid(row=row_idx, column=col_idx, sticky="ew", pady=4, padx=2)
                row_data[key] = var
            else:
                lbl = ttk.Label(inner_frame, text=str(val), anchor="center")
                lbl.grid(row=row_idx, column=col_idx, sticky="ew", pady=4, padx=2)
                row_data[key] = val
        all_rows_data.append(row_data)

    def apply_filter_and_sort(*args):
        for widget in inner_frame.winfo_children():
            if widget.grid_info() and int(widget.grid_info().get("row", 0)) > 0: widget.destroy()
        search_text = search_var.get().strip().lower()
        selected_filter_display = filter_col_var.get()
        selected_sort = sort_var.get()
        filter_key = "name"
        for k in all_keys:
            if headings_dict.get(k, k.capitalize()) == selected_filter_display:
                filter_key = k
                break
        filtered_rows = []
        for row in all_rows_data:
            val_str = row[filter_key].get().lower() if filter_key in editable_keys else str(row[filter_key]).lower()
            if search_text in val_str: filtered_rows.append(row)

        if selected_sort != "Default":
            def parse_sort_val(row, key, val_type):
                val = row[key].get().strip() if key in editable_keys else str(row[key])
                try:
                    if val_type == int: return int(val) if val else 0
                    if val_type == float: return float(val) if val else 0.0
                    if val_type == "date":
                        for fmt in ("%d/%m/%Y %H:%M:%S", "%d/%m/%Y"):
                            try:
                                return datetime.strptime(val, fmt)
                            except ValueError:
                                continue
                        return datetime.min
                    return val.lower()
                except ValueError:
                    return 0 if val_type in (int, float) else ""

            if selected_sort == "Name (A-Z)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "name", str))
            elif selected_sort == "Name (Z-A)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "name", str), reverse=True)
            elif selected_sort == "Count (Low ➔ High)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "count", int))
            elif selected_sort == "Count (High ➔ Low)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "count", int), reverse=True)
            elif selected_sort == "Import Price (Low ➔ High)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "import_price", float))
            elif selected_sort == "Import Price (High ➔ Low)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "import_price", float), reverse=True)
            elif selected_sort == "Export Price (Low ➔ High)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "export_price", float))
            elif selected_sort == "Export Price (High ➔ Low)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "export_price", float), reverse=True)
            elif selected_sort == "Date (Oldest ➔ Newest)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "date", "date"))
            elif selected_sort == "Date (Newest ➔ Oldest)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "date", "date"), reverse=True)
            elif selected_sort == "Last Update (Oldest ➔ Newest)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "last_update", "date"))
            elif selected_sort == "Last Update (Newest ➔ Oldest)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "last_update", "date"), reverse=True)

        for display_idx, row in enumerate(filtered_rows, start=1):
            for col_idx, key in enumerate(all_keys):
                if key in editable_keys:
                    entry = ttk.Entry(inner_frame, textvariable=row[key])
                    entry.grid(row=display_idx, column=col_idx, sticky="ew", pady=4, padx=2)
                else:
                    lbl = ttk.Label(inner_frame, text=str(row[key]), anchor="center")
                    lbl.grid(row=display_idx, column=col_idx, sticky="ew", pady=4, padx=2)
        canvas.configure(scrollregion=canvas.bbox("all"))

    search_var.trace_add("write", apply_filter_and_sort)
    filter_combo.bind("<<ComboboxSelected>>", apply_filter_and_sort)
    sort_combo.bind("<<ComboboxSelected>>", apply_filter_and_sort)
    apply_filter_and_sort()

    def save_updates():
        total_cost = 0
        current_time = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        products_to_update = []
        summary_changes = []
        for index, row in enumerate(all_rows_data, start=1):
            prod_id = row["id"]
            original_prod = prods[index - 1]
            new_name = row["name"].get().strip()
            new_origin = row["origin"].get().strip()
            new_date = row["date"].get().strip()
            new_count = row["count"].get().strip()
            new_import_price = row["import_price"].get().strip()
            new_export_price = row["export_price"].get().strip()

            is_changed = (
                    new_name != str(original_prod[1]) or
                    new_origin != str(original_prod[2]) or
                    new_date != str(original_prod[3]) or
                    str(new_count) != str(original_prod[4]) or
                    str(new_import_price) != str(original_prod[5]) or
                    str(new_export_price) != str(original_prod[6])
            )
            if not is_changed: continue

            summary_changes.append(f"Row {index} (ID: {prod_id}) - Updated")
            name = row["name"].get().strip()
            if not name: continue
            origin = row["origin"].get().strip()
            date = row["date"].get().strip()
            try:
                if " " not in date:
                    parsed_date = datetime.strptime(date, "%d/%m/%Y")
                    date = parsed_date.strftime("%d/%m/%Y 00:00:00")
                else:
                    parsed_date = datetime.strptime(date, "%d/%m/%Y %H:%M:%S")
                    date = parsed_date.strftime("%d/%m/%Y %H:%M:%S")
            except ValueError:
                messagebox.showerror(
                    "❗Error❗",
                    f"Invalid date format in {index}th product (ID: {prod_id})!\n\n"
                    f"Expected format: dd/mm/YYYY (31/12/2026)\n"
                    f"Or: dd/mm/YYYY HH:MM:SS"
                )
                return
            try:
                old_count = original_prod[4]
                old_import_price = original_prod[5]
                new_count_val = int(row["count"].get().strip()) if row["count"].get().strip() else 0
                new_import_price_val = float(row["import_price"].get().strip()) if row[
                    "import_price"].get().strip() else 0.0
                new_export_price_val = float(row["export_price"].get().strip()) if row[
                    "export_price"].get().strip() else 0.0
            except ValueError:
                messagebox.showerror("❗Error❗", f"Invalid count or price in product ID: {prod_id}!")
                return

            products_to_update.append(
                (name, origin, date, new_count_val, new_import_price_val, new_export_price_val, current_time, prod_id))
            total_cost += (new_import_price_val * new_count_val) - (old_import_price * old_count)

        if not summary_changes:
            messagebox.showinfo("Notification", "No changes were made.")
            return
        try:
            conn = sqlite3.connect(file_path)
            cursor = conn.cursor()
            cursor.execute("SELECT budget FROM list_info")
            current_budget = cursor.fetchone()[0]
            confirm_msg = "Are you sure you want to save the following changes?\n\n" + "\n".join(summary_changes[:10])
            if len(summary_changes) > 10:
                confirm_msg += f"\n... {len(summary_changes) - 10} more changes."
            cost_str = f"-${total_cost:,.2f}" if total_cost > 0 else f"+${abs(total_cost):,.2f} (Refund)"
            confirm_msg += f"\n\nAdditional Cost/Refund: {cost_str}\nNew budget: {current_budget} -> {current_budget - total_cost}"
            if not messagebox.askyesno("Confirmation", confirm_msg):
                return
            if not check_financial_feasibility(file_path, total_cost):
                return
            cursor.executemany('''
                UPDATE products 
                SET name = ?, origin = ?, date = ?, count = ?, import_price = ?, export_price = ?, last_update = ?
                WHERE id = ?
            ''', products_to_update)
            cursor.execute("UPDATE list_info SET budget = budget - ?", (total_cost,))
            cursor.execute("DELETE FROM products WHERE count <= 0")
            conn.commit()
            conn.close()
            main_tree_refresh()
            window.destroy()
            messagebox.showinfo("Success", "Data updated successfully!")
        except Exception as ERROR:
            messagebox.showerror("❗Error❗", f"Could not update data: {ERROR}")

    btn_frame = ttk.Frame(window)
    btn_frame.pack(side="bottom", pady=20)
    ttk.Button(btn_frame, text="CANCEL", bootstyle="outline-primary", command=window.destroy).pack(side="left", padx=10)
    ttk.Button(btn_frame, text="UPDATE", bootstyle="success", command=save_updates).pack(side="left", padx=10)


###################################################################################################################
def export_product_window(root, main_tree_refresh):
    if AppState.current_editing_file is None:
        messagebox.showerror("Error", "No list is currently being edited!")
        return
    config = load_config()
    font_size = config.get("font_size", 14)
    font_type = config.get("font_type", "Arial")
    file_path = Path(AppState.current_editing_file)

    prod_list_config = config.get("product_list", {})
    headings_dict = prod_list_config.get("headings", {})
    widths_dict = prod_list_config.get("widths", {})
    all_keys = ["id", "name", "origin", "date", "count", "import_price", "export_price", "last_update"]

    try:
        with sqlite3.connect(file_path) as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT id, name, origin, date, count, import_price, export_price, last_update FROM products")
            prods = cursor.fetchall()
    except Exception as e:
        messagebox.showerror("❗Error❗", f"Could not read data: {e}")
        return
    if not prods:
        messagebox.showinfo("Notification", "The list is currently empty. Nothing to export.")
        return

    window = ttk.Toplevel(master=root, title="Export Product Window", size=(800, 640))
    window.grab_set()

    filter_frame = ttk.LabelFrame(window)
    filter_frame.pack(side="top", fill="both", padx=15, pady=5)

    ttk.Label(filter_frame, text="Search:").pack(side="left", padx=5)
    search_var = tk.StringVar()
    search_entry = ttk.Entry(filter_frame, textvariable=search_var, width=20)
    search_entry.pack(side="left", fill='x', expand=True)

    sort_var = tk.StringVar()
    sort_options = [
        "Default", "Name (A-Z)", "Name (Z-A)", "Count (Low ➔ High)", "Count (High ➔ Low)",
        "Import Price (Low ➔ High)", "Import Price (High ➔ Low)",
        "Export Price (Low ➔ High)", "Export Price (High ➔ Low)",
        "Date (Oldest ➔ Newest)", "Date (Newest ➔ Oldest)",
        "Last Update (Oldest ➔ Newest)", "Last Update (Newest ➔ Oldest)"
    ]
    sort_combo = ttk.Combobox(filter_frame, textvariable=sort_var, values=sort_options, state="readonly", width=18)
    sort_combo.current(0)
    sort_combo.pack(side="right", padx=5)
    ttk.Label(filter_frame, text="Sort by:").pack(side="right", padx=5)

    filter_col_var = tk.StringVar()
    filter_options = [headings_dict.get(k, k.capitalize()) for k in all_keys]
    filter_combo = ttk.Combobox(filter_frame, textvariable=filter_col_var, values=filter_options, state="readonly", width=12)
    filter_combo.current(1)
    filter_combo.pack(side="right", padx=5)
    ttk.Label(filter_frame, text="Filter by:").pack(side="right", padx=5)

    container_frame = ttk.Frame(window)
    container_frame.pack(side="top", fill="both", expand=True, padx=15, pady=15)
    canvas = tk.Canvas(container_frame, highlightthickness=0, bd=0)
    scrollbar_y = ttk.Scrollbar(container_frame, orient="vertical", command=canvas.yview)
    scrollbar_x = ttk.Scrollbar(container_frame, orient="horizontal", command=canvas.xview)
    canvas.configure(yscrollcommand=scrollbar_y.set, xscrollcommand=scrollbar_x.set)
    scrollbar_y.pack(side="right", fill="y")
    scrollbar_x.pack(side="bottom", fill="x")
    canvas.pack(side="left", fill="both", expand=True)
    inner_frame = ttk.Frame(canvas)
    canvas.create_window((0, 0), window=inner_frame, anchor="nw")

    for i, key in enumerate(all_keys):
        inner_frame.columnconfigure(i, minsize=widths_dict.get(key, 120))
    inner_frame.columnconfigure(len(all_keys), minsize=100)

    for i, key in enumerate(all_keys):
        header_text = headings_dict.get(key, key.capitalize())
        lbl = ttk.Label(inner_frame, text=header_text, anchor="center", font=(font_type, font_size, "bold"))
        lbl.grid(row=0, column=i, sticky="ew", padx=2, pady=8)

    lbl_export = ttk.Label(inner_frame, text="Export Quantity", anchor="center", bootstyle="success",
                           font=(font_type, font_size, "bold"))
    lbl_export.grid(row=0, column=len(all_keys), sticky="ew", padx=2, pady=8)

    def on_frame_configure(event):
        canvas.configure(scrollregion=canvas.bbox("all"))

    def _on_mousewheel(event):
        if canvas.winfo_exists() and canvas.bbox("all")[3] > canvas.winfo_height():
            canvas.yview_scroll(int(-1 * (event.delta / 120) * 2), "units")

    def _on_shift_mousewheel(event):
        if canvas.winfo_exists() and canvas.bbox("all")[2] > canvas.winfo_width():
            canvas.xview_scroll(int(-1 * (event.delta / 120) * 2), "units")

    inner_frame.bind("<Configure>", on_frame_configure)
    canvas.bind("<Enter>", lambda e: (canvas.bind_all("<MouseWheel>", _on_mousewheel), canvas.bind_all("<Shift-MouseWheel>", _on_shift_mousewheel)))
    canvas.bind("<Leave>", lambda e: (canvas.unbind_all("<MouseWheel>"), canvas.unbind_all("<Shift-MouseWheel>")))

    all_rows_data = []
    for row_idx, prod in enumerate(prods, start=1):
        row_data = {}
        for col_idx, key in enumerate(all_keys):
            val = prod[col_idx]
            lbl = ttk.Label(inner_frame, text=str(val), anchor="center")
            lbl.grid(row=row_idx, column=col_idx, sticky="ew", pady=4, padx=2)
            row_data[key] = val

        export_var = tk.StringVar(value="0")
        entry = ttk.Entry(inner_frame, textvariable=export_var, justify="center")
        entry.grid(row=row_idx, column=len(all_keys), sticky="ew", pady=4, padx=2)
        row_data["export_qty"] = export_var
        all_rows_data.append(row_data)

    def apply_filter_and_sort(*args):
        for widget in inner_frame.winfo_children():
            if widget.grid_info() and int(widget.grid_info().get("row", 0)) > 0: widget.destroy()
        search_text = search_var.get().strip().lower()
        selected_filter_display = filter_col_var.get()
        selected_sort = sort_var.get()
        filter_key = "name"
        for k in all_keys:
            if headings_dict.get(k, k.capitalize()) == selected_filter_display:
                filter_key = k
                break

        filtered_rows = [r for r in all_rows_data if search_text in str(r[filter_key]).lower()]

        if selected_sort != "Default":
            def parse_sort_val(row, key, val_type):
                val = str(row[key])
                try:
                    if val_type == int: return int(val) if val else 0
                    if val_type == float: return float(val) if val else 0.0
                    if val_type == "date":
                        for fmt in ("%d/%m/%Y %H:%M:%S", "%d/%m/%Y"):
                            try:
                                return datetime.strptime(val, fmt)
                            except ValueError:
                                continue
                        return datetime.min
                    return val.lower()
                except ValueError:
                    return 0 if val_type in (int, float) else ""

            if selected_sort == "Name (A-Z)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "name", str))
            elif selected_sort == "Name (Z-A)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "name", str), reverse=True)
            elif selected_sort == "Count (Low ➔ High)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "count", int))
            elif selected_sort == "Count (High ➔ Low)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "count", int), reverse=True)
            elif selected_sort == "Import Price (Low ➔ High)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "import_price", float))
            elif selected_sort == "Import Price (High ➔ Low)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "import_price", float), reverse=True)
            elif selected_sort == "Export Price (Low ➔ High)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "export_price", float))
            elif selected_sort == "Export Price (High ➔ Low)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "export_price", float), reverse=True)
            elif selected_sort == "Date (Oldest ➔ Newest)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "date", "date"))
            elif selected_sort == "Date (Newest ➔ Oldest)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "date", "date"), reverse=True)
            elif selected_sort == "Last Update (Oldest ➔ Newest)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "last_update", "date"))
            elif selected_sort == "Last Update (Newest ➔ Oldest)":
                filtered_rows.sort(key=lambda r: parse_sort_val(r, "last_update", "date"), reverse=True)

        for display_idx, row in enumerate(filtered_rows, start=1):
            for col_idx, key in enumerate(all_keys):
                lbl = ttk.Label(inner_frame, text=str(row[key]), anchor="center")
                lbl.grid(row=display_idx, column=col_idx, sticky="ew", pady=4, padx=2)
            entry = ttk.Entry(inner_frame, textvariable=row["export_qty"], justify="center")
            entry.grid(row=display_idx, column=len(all_keys), sticky="ew", pady=4, padx=2)

        canvas.configure(scrollregion=canvas.bbox("all"))

    search_var.trace_add("write", apply_filter_and_sort)
    filter_combo.bind("<<ComboboxSelected>>", apply_filter_and_sort)
    sort_combo.bind("<<ComboboxSelected>>", apply_filter_and_sort)
    apply_filter_and_sort()

    def process_export():
        total_revenue = 0
        current_time = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        products_to_update = []
        summary_changes = []

        for index, row in enumerate(all_rows_data, start=1):
            prod_id = row["id"]
            current_count = int(row["count"])
            export_price = float(row["export_price"])

            try:
                qty_to_export = int(row["export_qty"].get().strip())
            except ValueError:
                messagebox.showerror("❗Error❗", f"Invalid export quantity (must be integer) in row ID: {prod_id}")
                return
            if qty_to_export == 0:
                continue
            if qty_to_export < 0:
                messagebox.showerror("❗Error❗", f"Cannot export negative quantity in row ID: {prod_id}")
                return
            if qty_to_export > current_count:
                messagebox.showerror("❗Error❗", f"Not enough stock to export {qty_to_export} units for {row['name']} (Current: {current_count})")
                return
            new_count = current_count - qty_to_export
            revenue = qty_to_export * export_price
            total_revenue += revenue

            products_to_update.append((new_count, current_time, prod_id))
            summary_changes.append(f"{row['name']} (ID: {prod_id}) - Exported: {qty_to_export} - Revenue: +${revenue:,.2f}")

        if not summary_changes:
            messagebox.showinfo("Notification", "No quantities were set to export.")
            return

        try:
            conn = sqlite3.connect(file_path)
            cursor = conn.cursor()
            cursor.execute("SELECT budget FROM list_info")
            current_budget = cursor.fetchone()[0]

            confirm_msg = "Are you sure you want to EXPORT the following products?\n\n" + "\n".join(
                summary_changes[:10])
            if len(summary_changes) > 10:
                confirm_msg += f"\n... {len(summary_changes) - 10} more items."
            confirm_msg += f"\n\nTotal Revenue: +${total_revenue:,.2f}\nNew budget: {current_budget:,.2f} -> ${(current_budget + total_revenue):,.2f}"
            if not messagebox.askyesno("Confirmation", confirm_msg):
                return
            if not check_financial_feasibility(file_path, -total_revenue):
                return
            cursor.executemany('''
                UPDATE products 
                SET count = ?, last_update = ?
                WHERE id = ?
            ''', products_to_update)

            cursor.execute("UPDATE list_info SET budget = budget + ?", (total_revenue,))
            cursor.execute("DELETE FROM products WHERE count <= 0")  # Tự động xóa sản phẩm <= 0
            conn.commit()
            conn.close()
            main_tree_refresh()
            window.destroy()
            messagebox.showinfo("Success", "Products exported successfully!")
        except Exception as ERROR:
            messagebox.showerror("❗Error❗", f"Could not process export: {ERROR}")

    btn_frame = ttk.Frame(window)
    btn_frame.pack(side="bottom", pady=20)
    ttk.Button(btn_frame, text="CANCEL", bootstyle="outline-primary", command=window.destroy).pack(side="left", padx=10)
    ttk.Button(btn_frame, text="EXPORT", bootstyle="success", command=process_export).pack(side="left", padx=10)