from functions.CONFIG import *
from data.state import *

def checking_data_folder():
    data_folder = Path("data")
    if not data_folder.exists():
        data_folder.mkdir(parents=True, exist_ok=True)
    return data_folder

def configuration_window(root, main_tree, main_tree_refresh):
    current_config = load_config()
    data_folder = checking_data_folder()

    window = ttk.Toplevel(master=root, title="Configuration Window", size=(760, 720))
    window.grab_set()

    btn_frame = ttk.Frame(window)
    btn_frame.pack(side="bottom", fill="x", pady=10)

    btn_cancel = ttk.Button(btn_frame, text="Cancel", bootstyle="danger", command=window.destroy)
    btn_cancel.pack(side="right", padx=10)

    btn_save = ttk.Button(btn_frame, text="Save Settings", bootstyle="success")
    btn_save.pack(side="right", padx=10)

    container_frame = ttk.Frame(window)
    container_frame.pack(side="top", fill="both", expand=True, padx=10, pady=10)

    canvas = tk.Canvas(container_frame, highlightthickness=0, bd=0)
    scrollbar_y = ttk.Scrollbar(container_frame, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=scrollbar_y.set)
    scrollbar_y.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)

    inner_frame = ttk.Frame(canvas)
    window_id = canvas.create_window((0, 0), window=inner_frame, anchor="nw")

    def on_frame_configure(event):
        canvas.configure(scrollregion=canvas.bbox("all"))

    def on_canvas_configure(event):
        canvas.itemconfig(window_id, width=event.width)

    inner_frame.bind("<Configure>", on_frame_configure)
    canvas.bind("<Configure>", on_canvas_configure)
    canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", lambda ev: canvas.yview_scroll(int(-1 * (ev.delta / 120)), "units")))
    canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))

    db_files = ["None"]
    if data_folder.exists():
        for file in os.listdir(data_folder):
            if file.endswith(".db"): db_files.append(file.replace(".db", ""))

    default_list_val = current_config.get("default_list", "None")
    if default_list_val not in db_files: default_list_val = "None"

    default_file_var = tk.StringVar(value=default_list_val)
    font_type_var = tk.StringVar(value=current_config.get("font_type", "Arial"))
    font_size_var = tk.IntVar(value=current_config.get("font_size", 14))
    master_budget_var = tk.StringVar(value=str(current_config.get("master_budget", 0.0)))
    master_threshold_var = tk.StringVar(value=str(current_config.get("master_threshold", 0.0)))
    quick_adjust_var = tk.StringVar()

    general_frame = ttk.LabelFrame(inner_frame, text="General & Financial Settings")
    general_frame.pack(fill="x", pady=10, padx=5)

    ttk.Label(general_frame, text="Default list:").grid(row=0, column=0, sticky="w", pady=5, padx=5)
    ttk.Combobox(general_frame, textvariable=default_file_var, values=db_files, state="readonly", width=25).grid(row=0, column=1, sticky="w", padx=5, pady=5)

    ttk.Label(general_frame, text="Font Type:").grid(row=1, column=0, sticky="w", pady=5, padx=5)
    ttk.Combobox(general_frame, textvariable=font_type_var, values=["Arial", "Helvetica", "Consolas", "Tahoma"], width=25).grid(row=1, column=1, sticky="w", padx=5, pady=5)

    ttk.Label(general_frame, text="Font Size:").grid(row=2, column=0, sticky="w", pady=5, padx=5)
    ttk.Spinbox(general_frame, from_=8, to=32, textvariable=font_size_var, width=5).grid(row=2, column=1, sticky="w", padx=5, pady=5)

    ttk.Label(general_frame, text="Master Budget ($):").grid(row=0, column=2, sticky="e", pady=5, padx=20)
    ttk.Entry(general_frame, textvariable=master_budget_var, width=15).grid(row=0, column=3, sticky="w", padx=5, pady=5)

    ttk.Label(general_frame, text="Master Threshold ($):").grid(row=1, column=2, sticky="e", pady=5, padx=20)
    ttk.Entry(general_frame, textvariable=master_threshold_var, width=15).grid(row=1, column=3, sticky="w", padx=5, pady=5)

    ttk.Label(general_frame, text="Master adjust (+/-):").grid(row=2, column=2, sticky="e", pady=5, padx=20)
    adjust_entry = ttk.Entry(general_frame, textvariable=quick_adjust_var, width=15)
    adjust_entry.grid(row=2, column=3, sticky="w", padx=5, pady=5)
    ttk.Label(general_frame, text="(Press ENTER to apply)", font=("", 8, "italic")).grid(row=3, column=3, sticky="w", padx=5, pady=(0, 5))

    def apply_quick_adjust(event):
        try:
            adj_amount = float(quick_adjust_var.get().strip())
            if adj_amount == 0: return

            current_master = float(master_budget_var.get().strip())
            current_threshold = float(master_threshold_var.get().strip())
            projected_master = current_master + adj_amount

            # 1. Quét tổng tài sản các List
            total_lists_budget = 0.0
            for file in data_folder.glob("*.db"):
                try:
                    with sqlite3.connect(file) as conn:
                        cursor = conn.cursor()
                        cursor.execute("SELECT count(name) FROM sqlite_master WHERE type='table' AND name='list_info'")
                        if cursor.fetchone()[0] == 1:
                            cursor.execute("SELECT budget FROM list_info")
                            res = cursor.fetchone()
                            if res: total_lists_budget += res[0]
                except Exception:
                    pass
            projected_global = projected_master + total_lists_budget

            # 2. Kiểm tra lỗi phá sản hệ thống (Global < 0)
            if projected_global < 0:
                messagebox.showerror("Error", f"Global Budget Cannot Be Negative!\n\nProjected Master: ${projected_master:,.2f}\nTotal Allocated in Lists: ${total_lists_budget:,.2f}\nProjected Global: ${projected_global:,.2f}", parent=window)
                return

            # 3. Kiểm tra Threshold Master (Nếu giảm quá mức an toàn)
            if adj_amount < 0 and projected_master < current_threshold:
                warning_msg = (
                    f"Warning: Subtracting ${abs(adj_amount):,.2f} will cause the Master Budget "
                    f"to fall below the safety threshold.\n\n"
                    f"Current Master Budget: ${current_master:,.2f}\n"
                    f"Projected Master: ${projected_master:,.2f}\n"
                    f"Required Threshold: ${current_threshold:,.2f}\n\n"
                    f"Do you want to proceed anyway?"
                )
                if not messagebox.askyesno("Financial Warning", warning_msg, parent=window):
                    return

            # Áp dụng thay đổi lên giao diện
            master_budget_var.set(str(projected_master))
            quick_adjust_var.set("")

            # Thay vì lưu luôn, chỉ thông báo thay đổi trên UI để nhắc người dùng bấm Save Settings
            messagebox.showinfo("Adjustment Applied", f"Master Budget adjusted to ${projected_master:,.2f}.\n\nNote: Please click 'Save Settings' to apply this change permanently.", parent=window)

        except ValueError:
            messagebox.showerror("Error", "Please enter a valid numeric adjustment (e.g. 100 or -50).", parent=window)

    adjust_entry.bind("<Return>", apply_quick_adjust)

    list_keys = ["product_list", "file_list", "misc_list", "stats_list"]
    display_names = {
        "product_list": "Main Product List Config",
        "file_list": "File Manager Config",
        "misc_list": "Import/Export List Config",
        "stats_list": "Statistics List Config"
    }
    width_vars = {k: {} for k in list_keys}

    for list_key in list_keys:
        list_config = current_config.get(list_key, {})
        headings = list_config.get("headings", {})
        widths = list_config.get("widths", {})
        if not headings: continue

        frame = ttk.LabelFrame(inner_frame, text=display_names[list_key])
        frame.pack(fill="x", pady=10, padx=5)
        col_idx = 0
        for field_key, header_name in headings.items():
            var = tk.IntVar(value=widths.get(field_key, 150))
            width_vars[list_key][field_key] = var
            col_frame = ttk.Frame(frame)
            col_frame.grid(row=0, column=col_idx, padx=5, pady=5, sticky="n")
            ttk.Label(col_frame, text=header_name, font=("", 10, "bold")).pack(side="top", pady=2)
            ttk.Label(col_frame, text=f"({field_key})", font=("", 8)).pack(side="top", pady=2)
            ttk.Entry(col_frame, textvariable=var, width=8, justify="center").pack(side="top", pady=5)
            col_idx += 1

    finance_frame = ttk.LabelFrame(inner_frame, text="List Financial Settings & Transfer")
    finance_frame.pack(fill="x", pady=20, padx=5)

    list_threshold_var = tk.StringVar(value="0.0")

    if AppState.current_editing_file:
        current_list_name = Path(AppState.current_editing_file).stem

        # Đọc Threshold hiện tại của List
        try:
            with sqlite3.connect(AppState.current_editing_file) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT count(name) FROM sqlite_master WHERE type='table' AND name='list_info'")
                if cursor.fetchone()[0] == 1:
                    cursor.execute("SELECT min_threshold FROM list_info")
                    res = cursor.fetchone()
                    if res: list_threshold_var.set(str(res[0]))
        except Exception:
            pass

        sub_finance_frame = ttk.Frame(finance_frame)
        sub_finance_frame.pack(pady=10)

        ttk.Label(sub_finance_frame, text=f"Target List: {current_list_name}", font=("", 11, "bold")).grid(row=0, column=0, columnspan=2, pady=(0, 10))

        ttk.Label(sub_finance_frame, text="+ Deposit / - Withdraw ($):").grid(row=1, column=0, sticky="e", padx=5, pady=5)
        transfer_var = tk.StringVar()
        transfer_entry = ttk.Entry(sub_finance_frame, textvariable=transfer_var, justify="center", width=15, font=("", 11, "bold"))
        transfer_entry.grid(row=1, column=1, sticky="w", padx=5, pady=5)

        ttk.Label(sub_finance_frame, text="List Threshold ($):").grid(row=2, column=0, sticky="e", padx=5, pady=5)
        ttk.Entry(sub_finance_frame, textvariable=list_threshold_var, justify="center", width=15).grid(row=2, column=1, sticky="w", padx=5, pady=5)

        def process_transfer(event):
            try:
                amount = float(transfer_var.get().strip())
                if amount == 0: return

                cfg = load_config()
                master_budget = float(master_budget_var.get().strip())  # Sử dụng giá trị hiện tại trên UI
                master_threshold = float(master_threshold_var.get().strip())

                if amount > 0:
                    if (master_budget - amount) < master_threshold:
                        warning_msg = (
                            f"Warning: Depositing ${amount:,.2f} will cause the Master Budget "
                            f"to fall below the safety threshold.\n\n"
                            f"Current Master Budget: ${master_budget:,.2f}\n"
                            f"Target Master Budget: ${(master_budget - amount):,.2f}\n"
                            f"Required Threshold: ${master_threshold:,.2f}\n\n"
                            f"Do you want to proceed anyway?"
                        )
                        confirm_risk = messagebox.askyesno("Financial Warning", warning_msg, parent=window)
                        if not confirm_risk: return

                action = "DEPOSIT TO" if amount > 0 else "WITHDRAW FROM"
                abs_amount = abs(amount)

                confirm = messagebox.askyesno("Confirm Transfer", f"Are you sure you want to {action} {current_list_name}?\n\nAmount: ${abs_amount:,.2f}", parent=window)

                if confirm:
                    cfg["master_budget"] = master_budget - amount
                    with open("config.json", "w", encoding="utf-8") as f:
                        json.dump(cfg, f, indent=4)
                    master_budget_var.set(str(cfg["master_budget"]))

                    conn = sqlite3.connect(AppState.current_editing_file)
                    cursor = conn.cursor()
                    cursor.execute("UPDATE list_info SET budget = budget + ?", (amount,))
                    conn.commit()
                    conn.close()

                    messagebox.showinfo("Success", "Transfer completed successfully!", parent=window)
                    transfer_var.set("")
            except ValueError:
                messagebox.showerror("Error", "Please enter a valid numeric amount.", parent=window)
            except Exception as e:
                messagebox.showerror("Error", f"System error: {e}", parent=window)

        transfer_entry.bind("<Return>", process_transfer)
        ttk.Label(sub_finance_frame, text="(Press ENTER on Transfer box to execute)", font=("", 9, "italic")).grid(row=3, column=0, columnspan=2, pady=5)
    else:
        ttk.Label(finance_frame, text="No active list selected for transfer or configuration.", foreground="red", font=("", 11)).pack(pady=20)

    # =========================================================
    # LƯU TOÀN BỘ CẤU HÌNH UI
    # =========================================================
    def save_all():
        try:
            total_lists_budget = 0.0
            for file in data_folder.glob("*.db"):
                try:
                    with sqlite3.connect(file) as conn:
                        cursor = conn.cursor()
                        cursor.execute("SELECT count(name) FROM sqlite_master WHERE type='table' AND name='list_info'")
                        if cursor.fetchone()[0] == 1:
                            cursor.execute("SELECT budget FROM list_info")
                            res = cursor.fetchone()
                            if res: total_lists_budget += res[0]
                except Exception:
                    pass

            try:
                new_master_budget = float(master_budget_var.get().strip())
                new_master_threshold = float(master_threshold_var.get().strip())
            except ValueError:
                messagebox.showerror("Error", "Master Budget & Threshold must be valid numbers!", parent=window)
                return

            if new_master_budget + total_lists_budget < 0:
                messagebox.showerror("Error", f"Global Budget Cannot Be Negative!\n\nNew Master Budget: ${new_master_budget:,.2f}\nTotal Allocated in Lists: ${total_lists_budget:,.2f}\nProjected Global: ${(new_master_budget + total_lists_budget):,.2f}", parent=window)
                return

            current_config["default_list"] = None if default_file_var.get() == "None" else default_file_var.get()
            current_config["font_type"] = font_type_var.get().strip()
            current_config["font_size"] = font_size_var.get()
            current_config["master_budget"] = new_master_budget
            current_config["master_threshold"] = new_master_threshold

            for list_key in list_keys:
                if list_key not in current_config: current_config[list_key] = {"widths": {}}
                for field_key, var in width_vars[list_key].items():
                    current_config[list_key]["widths"][field_key] = int(var.get())

            with open("config.json", "w", encoding="utf-8") as f:
                json.dump(current_config, f, indent=4)

            if AppState.current_editing_file:
                try:
                    new_list_thresh = float(list_threshold_var.get().strip())
                    with sqlite3.connect(AppState.current_editing_file) as conn:
                        conn.execute("UPDATE list_info SET min_threshold = ?", (new_list_thresh,))
                except ValueError:
                    messagebox.showerror("Error", "List Threshold must be a valid number!", parent=window)
                    return

            if main_tree:
                for col_id, new_w in current_config.get("product_list", {}).get("widths", {}).items():
                    try:
                        main_tree.column(col_id, width=new_w)
                    except tk.TclError:
                        pass
                main_tree_refresh()
            window.destroy()
            messagebox.showinfo("Success", "Configuration saved successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"An unexpected error occurred:\n{e}", parent=window)

    btn_save.config(command=save_all)