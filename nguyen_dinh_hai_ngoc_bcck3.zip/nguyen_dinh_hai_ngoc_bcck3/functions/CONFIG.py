from functions.LIBRARY import *

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_FILE = BASE_DIR / "config.json"
DATA_DIR = BASE_DIR / "data"

def load_config():
    default_config = {
        "default_list": None,
        "master_budget": 0.0,
        "master_threshold": 0.0,
        "stats_list": {
            "headings": {"list_name": "List", "budget": "Budget", "last_update": "Last update"},
            "widths": {"list_name": 250, "budget": 150, "last_update": 200}
        },
        "product_list": {
            "headings": {"id": "ID", "name": "Product", "origin": "Place of origin", "date": "Date", "count": "Left", "import_price": "Import Price", "export_price": "Export Price", "last_update": "Last update"},
            "widths": {"id": 250, "name": 450, "origin": 450, "date": 200, "count": 150, "import_price": 150, "export_price": 150, "last_update": 300}
        },
        "file_list": {
            "headings": {"filename": "Save(s)", "last_update": "Last update"},
            "widths": {"filename": 500, "last_update": 400}
        },
        "misc_list": {
            "headings": {"name": "Product", "origin": "Place of origin", "date": "Date", "count": "Count", "import_price": "Import Price", "export_price": "Export Price"},
            "widths": {"id": 150, "name": 450, "origin": 450, "date": 200, "count": 150, "import_price": 150, "export_price": 150, "last_update": 300}
        },
        "font_size": 14,
        "font_type": "Arial"
    }

    # 1. Nếu file config chưa tồn tại, tạo mới
    if not CONFIG_FILE.exists():
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(default_config, f, indent=4)
        return default_config

    # 2. Nếu đã tồn tại, đọc file lên
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            config = json.load(f)
    except json.JSONDecodeError:
        # Đề phòng trường hợp file config.json bị lỗi/rỗng
        config = default_config

    needs_rewrite = False
    current_default = config.get("default_list")

    # 3. SỬA LỖI VÀ TỰ ĐỘNG BẢO TRÌ (Self-healing)
    if current_default == "None":
        # Nếu vô tình bị lưu là chuỗi "None", chuyển về None (sẽ thành null trong JSON)
        config["default_list"] = None
        needs_rewrite = True
    elif current_default is not None:
        # Nếu có tên list được set, kiểm tra xem file .db đó có tồn tại không
        db_path = DATA_DIR / f"{current_default}.db"
        if not db_path.exists():
            # File đã bị xóa ở đâu đó, tự động reset default_list về None
            config["default_list"] = None
            needs_rewrite = True

    # 4. Ghi đè lại file nếu phát hiện ra bất kỳ lỗi nào ở trên
    if needs_rewrite:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=4)

    return config