from functions.CONFIG import *
from data.state import *

def is_valid(file_name):
    for c in file_name:
        if not (c.isalpha() or c.isdigit() or c == "_"): return False
    return True

def checking_data_folder():
    data_folder = Path("data")
    if not data_folder.exists():
        data_folder.mkdir(parents=True, exist_ok=True)
    return data_folder

def get_last_modified_date(file_path):
    path_obj = Path(file_path)
    if path_obj.exists():
        timestamp = path_obj.stat().st_mtime
        dt_object = datetime.fromtimestamp(timestamp)
        return dt_object.strftime("%d/%m/%Y %H:%M:%S")
    return None

def stats_and_info_window(root):
    config = load_config()
    font_size = config.get("font_size", 14)
    font_type = config.get("font_type", "Arial")

    master_budget = config.get("master_budget", 0.0)
    stats_config = config.get("stats_list", {})
    headings_dict = stats_config.get("headings",
                                     {"list_name": "List Name", "budget": "Budget", "last_update": "Last Update"})
    widths_dict = stats_config.get("widths", {"list_name": 250, "budget": 150, "last_update": 200})

    window = ttk.Toplevel(master=root, title="STATS & INFO", size=(900, 650))
    window.grab_set()

    notebook = ttk.Notebook(window)
    notebook.pack(fill="both", expand=True, padx=10, pady=10)

    tab_stats = ttk.Frame(notebook)
    notebook.add(tab_stats, text=" 📊 Statistics ")

    data_folder = checking_data_folder()
    total_allocated_budget = master_budget
    current_list_budget = 0.0
    list_stats_cache = []  # Dùng để lưu trữ bộ đệm phục vụ cho việc lọc dữ liệu

    # --- 1. QUÉT DỮ LIỆU ---
    for file_path in data_folder.glob("*.db"):
        list_name = file_path.stem
        mtime = datetime.fromtimestamp(file_path.stat().st_mtime).strftime("%d/%m/%Y %H:%M:%S")
        list_budget = 0.0

        try:
            with sqlite3.connect(file_path) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT count(name) FROM sqlite_master WHERE type='table' AND name='list_info'")
                if cursor.fetchone()[0] == 1:
                    cursor.execute("SELECT budget FROM list_info")
                    res = cursor.fetchone()
                    if res: list_budget = res[0]
        except Exception:
            pass

        total_allocated_budget += list_budget

        # Cấu trúc cache: (Tên List, Số tiền Float (để sort), Số tiền Format (để hiển thị), Ngày Update, Tên File gốc)
        list_stats_cache.append({
            "list_name": list_name,
            "budget_val": list_budget,
            "budget_str": f"${list_budget:,.2f}",
            "last_update": mtime,
            "file_name": file_path.name
        })

        if AppState.current_editing_file and Path(AppState.current_editing_file).name == file_path.name:
            current_list_budget = list_budget

    # --- 2. VẼ UI THÔNG TIN TỔNG QUAN ---
    summary_frame = ttk.Frame(tab_stats)
    summary_frame.pack(side="top", fill="x", pady=(10, 10))

    card_master = ttk.LabelFrame(summary_frame, text="Master Budget")
    card_master.pack(side="left", fill="both", expand=True, padx=5)
    ttk.Label(card_master, text=f"${master_budget:,.2f}", font=(font_type, font_size + 4, "bold"), bootstyle="success").pack(pady=10)

    card_allocated = ttk.LabelFrame(summary_frame, text="Total Lists Budget")
    card_allocated.pack(side="left", fill="both", expand=True, padx=5)
    ttk.Label(card_allocated, text=f"${total_allocated_budget:,.2f}", font=(font_type, font_size + 4, "bold"), bootstyle="warning").pack(pady=10)

    card_current = ttk.LabelFrame(summary_frame, text="Current Active List")
    card_current.pack(side="left", fill="both", expand=True, padx=5)
    if AppState.current_editing_file:
        ttk.Label(card_current, text=f"${current_list_budget:,.2f}", font=(font_type, font_size + 4, "bold"), bootstyle="info").pack(pady=10)
    else:
        ttk.Label(card_current, text="None", font=(font_type, font_size, "italic")).pack(pady=10)

    # --- 3. VẼ UI BỘ LỌC (Filter & Sort) ---
    filter_frame = ttk.Frame(tab_stats)
    filter_frame.pack(side="top", fill="x", padx=5, pady=5)

    ttk.Label(filter_frame, text="Search:").pack(side="left", padx=5)
    search_var = tk.StringVar()
    search_entry = ttk.Entry(filter_frame, textvariable=search_var, width=20)
    search_entry.pack(side="left", fill='x', expand=True)

    sort_var = tk.StringVar()
    sort_options = [
        "Default",
        "Name (A-Z)", "Name (Z-A)",
        "Budget (Low ➔ High)", "Budget (High ➔ Low)",
        "Date (Oldest ➔ Newest)", "Date (Newest ➔ Oldest)"
    ]
    sort_combo = ttk.Combobox(filter_frame, textvariable=sort_var, values=sort_options, state="readonly", width=18)
    sort_combo.current(0)
    sort_combo.pack(side="right", padx=5)
    ttk.Label(filter_frame, text="Sort by:").pack(side="right", padx=5)

    filter_col_var = tk.StringVar()
    filter_options = [headings_dict.get("list_name", "List Name"), headings_dict.get("last_update", "Last Update")]
    filter_combo = ttk.Combobox(filter_frame, textvariable=filter_col_var, values=filter_options, state="readonly",
                                width=15)
    filter_combo.current(0)
    filter_combo.pack(side="right", padx=5)
    ttk.Label(filter_frame, text="Filter by:").pack(side="right", padx=5)

    # --- 4. VẼ UI BẢNG THỐNG KÊ (Treeview) ---
    table_frame = ttk.LabelFrame(tab_stats, text="Detailed List Budgets")
    table_frame.pack(side="top", fill="both", expand=True, padx=5, pady=5)

    columns = ("list_name", "budget", "last_update")
    stats_tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=10)

    for col in columns:
        stats_tree.heading(col, text=headings_dict.get(col, col))
        anchor_val = "e" if col == "budget" else "center" if col == "last_update" else "w"
        col_width = widths_dict.get(col, 150)
        stats_tree.column(col, width=col_width, minwidth=col_width, stretch=False, anchor=anchor_val)

    def disable_resize(event):
        if stats_tree.identify_region(event.x, event.y) == "separator": return "break"

    stats_tree.bind('<Button-1>', disable_resize)
    stats_tree.bind('<B1-Motion>', disable_resize)

    scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=stats_tree.yview)
    stats_tree.configure(yscrollcommand=scrollbar.set)
    scrollbar.pack(side="right", fill="y")
    stats_tree.pack(side="left", fill="both", expand=True)

    stats_tree.tag_configure("active_row", background="#005A9E", foreground="#FFFFFF", font=(font_type, font_size, "bold"))
    stats_tree.tag_configure("normal_row", font=(font_type, font_size))

    # --- 5. LOGIC LỌC VÀ SẮP XẾP ---
    def apply_filter_and_sort(*args):
        # Xóa dữ liệu cũ
        for item in stats_tree.get_children():
            stats_tree.delete(item)

        search_text = search_var.get().strip().lower()
        selected_filter_display = filter_col_var.get()
        selected_sort = sort_var.get()

        # Xác định key để lọc
        filter_key = "list_name"
        if selected_filter_display == headings_dict.get("last_update", "Last Update"):
            filter_key = "last_update"

        # 1. Lọc
        filtered_stats = []
        for stat in list_stats_cache:
            if search_text in str(stat[filter_key]).lower():
                filtered_stats.append(stat)

        # 2. Sắp xếp
        if selected_sort != "Default":
            def parse_date(date_str):
                for fmt in ("%d/%m/%Y %H:%M:%S", "%d/%m/%Y"):
                    try:
                        return datetime.strptime(date_str.strip(), fmt)
                    except ValueError:
                        continue
                return datetime.min

            if selected_sort == "Name (A-Z)":
                filtered_stats.sort(key=lambda x: x["list_name"].lower())
            elif selected_sort == "Name (Z-A)":
                filtered_stats.sort(key=lambda x: x["list_name"].lower(), reverse=True)
            elif selected_sort == "Budget (Low ➔ High)":
                filtered_stats.sort(key=lambda x: x["budget_val"])
            elif selected_sort == "Budget (High ➔ Low)":
                filtered_stats.sort(key=lambda x: x["budget_val"], reverse=True)
            elif selected_sort == "Date (Oldest ➔ Newest)":
                filtered_stats.sort(key=lambda x: parse_date(x["last_update"]))
            elif selected_sort == "Date (Newest ➔ Oldest)":
                filtered_stats.sort(key=lambda x: parse_date(x["last_update"]), reverse=True)
        else:
            # Mặc định sort theo tên A-Z
            filtered_stats.sort(key=lambda x: x["list_name"].lower())

        # 3. Đổ dữ liệu lên Treeview
        current_file_name = Path(AppState.current_editing_file).name if AppState.current_editing_file else ""

        for stat in filtered_stats:
            row_tags = ("active_row",) if stat["file_name"] == current_file_name else ("normal_row",)
            row_values = (stat["list_name"], stat["budget_str"], stat["last_update"])
            stats_tree.insert("", "end", values=row_values, tags=row_tags)

    # Ràng buộc sự kiện
    search_var.trace_add("write", apply_filter_and_sort)
    filter_combo.bind("<<ComboboxSelected>>", apply_filter_and_sort)
    sort_combo.bind("<<ComboboxSelected>>", apply_filter_and_sort)
    apply_filter_and_sort()

    tab_info = ttk.Frame(notebook)
    notebook.add(tab_info, text=" 📖 User Guide ")

    guide_text = """
    Very useful guide (fr):
    
    1. NEW LIST
    Create a new list by typing the name of the list you want to create.
    
    2. EDIT LIST
    Select the list you want to edit by typing the name of the existing list.
    Alternatively, you can also double-click on the list you want to edit.
    
    3. DELETE LIST
    Delete a existing list by typing the name of the list you want to delete.
    Alternatively, you can also select the list and press delete key.
    
    4. STAT & INFO
    -Statistics: show information of master budget, total budget, and lists budget
    -User guide:
    
    5. IMPORT PRODUCT(s)
    -ADD: add a new product to import
    -IMPORT: import product(s)
    
    6. UPDATE PRODUCT(s)
    You can edit the product datas; press UPDATE to save.
    
    7. EXPORT PRODUCT(s)
    You can export products by entering the quantity you wish.
    
    8. CONFIGURATION
    Feature:
    - Set default list
    - Change text size
    - Adjust UI
    - Deposit/Withdraw finance
    """

    txt_info = scrolledtext.ScrolledText(tab_info, wrap=tk.WORD, font=(font_type, font_size))
    txt_info.pack(fill="both", expand=True, padx=10, pady=10)
    txt_info.insert(tk.INSERT, guide_text)
    txt_info.configure(state="disabled")

    ttk.Button(window, text="Close", command=window.destroy, bootstyle="secondary", width=15).pack(pady=10)