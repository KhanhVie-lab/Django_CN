import tkinter as tk
import ttkbootstrap as ttk
from tkinter import messagebox, scrolledtext

import os
import json
import sqlite3
from pathlib import Path
from datetime import datetime
import uuid