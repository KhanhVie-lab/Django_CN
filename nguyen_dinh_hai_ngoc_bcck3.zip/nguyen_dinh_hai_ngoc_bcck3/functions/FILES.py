from functions.CONFIG import *
from data.state import *

def is_valid(file_name):
    for c in file_name:
        if not (c.isalpha() or c.isdigit() or c=="_"): return False
    return True

def checking_data_folder():
    data_folder = Path("data")
    if not data_folder.exists():
        data_folder.mkdir(parents=True, exist_ok=True)
    return data_folder

def get_last_modified_date(file_path):
    path_obj = Path(file_path)
    if path_obj.exists():
        timestamp = path_obj.stat().st_mtime
        dt_object = datetime.fromtimestamp(timestamp)
        return dt_object.strftime("%d/%m/%Y %H:%M:%S")
    return None

###################################################################################################################
def new_file_window(root):
    checking_data_folder()
    config = load_config()
    file_list_headings = config["file_list"]["headings"]
    file_list_widths = config["file_list"]["widths"]
    font_size = config["font_size"]
    font_type = config["font_type"]

    def create(event):
        file_name = new_file_name.get().strip().strip("_")
        if file_name:
            if not is_valid(file_name):
                messagebox.showerror("Invalid Name Detected", f"File name only contain alphabetical characters, digits, space, and underscore")
                return
            data_folder = checking_data_folder()
            file_path = data_folder / (file_name + ".db")
            override = False
            if file_path.exists():
                confirm = messagebox.askyesno("Existed Save Detected", f'"{file_name}" already exists. Do you want to override it?')
                if confirm:
                    override = True
                else:
                    return
            if not override:
                confirm = messagebox.askyesno("Confirmation", f"Do you want to create file named {file_name}?")
                if not confirm: return
            try:
                if override:
                    if AppState.current_editing_file == file_path:
                        messagebox.showerror("Editing File Encountered", f"Unable to override {file_name} due to being editing")
                        return
                    file_path.unlink()
                conn = sqlite3.connect(file_path)
                cursor = conn.cursor()
                cursor.execute('''
                CREATE TABLE IF NOT EXISTS products (
                    id TEXT PRIMARY KEY,
                    name TEXT,
                    origin TEXT,
                    date TEXT,
                    count INTEGER,
                    import_price REAL,
                    export_price REAL,
                    last_update TEXT
                )
                ''')
                # Tạo bảng cấu hình riêng cho List này
                cursor.execute('''
                CREATE TABLE IF NOT EXISTS list_info (
                    budget REAL,
                    min_threshold REAL
                )
                ''')
                # Mặc định gán ngân sách khởi điểm là 0 (hoặc số do user nhập)
                cursor.execute('INSERT INTO list_info (budget, min_threshold) VALUES (0.0, 0.0)')
                conn.commit()
                conn.close()
                refresh()
            except Exception as ERROR:
                messagebox.showerror("❗Error❗", f"Error encountered: {ERROR}")
        return

    window = ttk.Toplevel(
        master=root,
        title="New List Window",
        size=(640, 640)
    )
    window.grab_set()

    all_files_cache = []

    def apply_file_filter(*args):
        """Hàm nâng cấp: Lọc theo cột chỉ định và Sắp xếp theo tiêu chí được chọn"""
        for item in file_list.get_children():
            file_list.delete(item)
        search_text = new_file_name.get().strip().lower()
        selected_filter_display = filter_col_var.get()
        selected_sort = sort_var.get()
        # Xác định index cột cần lọc (0: filename, 1: last_update)
        filter_index = 0
        if selected_filter_display == file_list_headings["last_update"]:
            filter_index = 1
        # 1. Tiến hành lọc dữ liệu (Filter)
        filtered_files = []
        for item in all_files_cache:
            # item gồm: (file_name, last_update, is_editing)
            val_to_search = str(item[filter_index]).lower()
            if search_text in val_to_search:
                filtered_files.append(item)
        # 2. Tiến hành sắp xếp dữ liệu (Sort)
        if selected_sort != "Default":
            from datetime import datetime
            def parse_date(date_str):
                # Hàm hỗ trợ ép kiểu ngày tháng để sắp xếp chính xác
                for fmt in ("%d/%m/%Y %H:%M:%S", "%d/%m/%Y"):
                    try:
                        return datetime.strptime(date_str.strip(), fmt)
                    except ValueError:
                        continue
                return datetime.min
            if selected_sort == "Name (A-Z)":
                filtered_files.sort(key=lambda x: x[0].lower())
            elif selected_sort == "Name (Z-A)":
                filtered_files.sort(key=lambda x: x[0].lower(), reverse=True)
            elif selected_sort == "Date (Oldest ➔ Newest)":
                filtered_files.sort(key=lambda x: parse_date(x[1]))
            elif selected_sort == "Date (Newest ➔ Oldest)":
                filtered_files.sort(key=lambda x: parse_date(x[1]), reverse=True)
        # 3. Đổ dữ liệu đã xử lý xong lên giao diện Treeview
        file_list.tag_configure("odd", background="#1F1F1F", foreground="#FFFFFF", font=(font_type, font_size))
        file_list.tag_configure("even", background="#2F2F2F", foreground="#FFFFFF", font=(font_type, font_size))
        file_list.tag_configure("editing", background="#005A9E", foreground="#FFFFFF", font=(font_type, font_size, "bold"))
        visible_idx = 0
        for file_name, last_update, is_editing in filtered_files:
            visible_idx += 1
            if is_editing:
                tag = "editing"
            else:
                tag = "odd" if visible_idx & 1 else "even"
            file_list.insert("", "end", values=(file_name, last_update), tags=(tag,))

    def refresh():
        all_files_cache.clear()
        data_folder = checking_data_folder()
        for file in os.listdir(data_folder):
            if file.endswith(".db"):
                file_path = data_folder / file
                last_update = get_last_modified_date(file_path)
                if last_update is None:
                    continue
                is_editing = False
                if AppState.current_editing_file and Path(AppState.current_editing_file) == file_path:
                    is_editing = True
                all_files_cache.append((file, last_update, is_editing))
        apply_file_filter()

    new_file_frame = ttk.Frame(window)
    new_file_name = tk.StringVar()
    ttk.Label(new_file_frame, text="New list:").pack(side="left", padx=5)
    new_file_entry = ttk.Entry(new_file_frame, textvariable=new_file_name, width=20)
    new_file_entry.bind('<Return>', create)
    new_file_entry.pack(side="left", fill="x", expand=True, padx=5)
    ttk.Label(new_file_frame, text="Filter by:").pack(side="left", padx=5)
    filter_col_var = tk.StringVar()
    filter_options = [file_list_headings["filename"], file_list_headings["last_update"]]
    filter_combo = ttk.Combobox(new_file_frame, textvariable=filter_col_var, values=filter_options, state="readonly", width=12)
    filter_combo.current(0)
    filter_combo.pack(side="left", padx=5)
    ttk.Label(new_file_frame, text="Sort by:").pack(side="left", padx=5)
    sort_var = tk.StringVar()
    sort_options = [
        "Default",
        "Name (A-Z)", "Name (Z-A)",
        "Date (Oldest ➔ Newest)", "Date (Newest ➔ Oldest)"
    ]
    sort_combo = ttk.Combobox(new_file_frame, textvariable=sort_var, values=sort_options, state="readonly", width=18)
    sort_combo.current(0)
    sort_combo.pack(side="left", padx=5)
    new_file_frame.pack(side="top", fill="x", pady=10, padx=5)
    new_file_name.trace_add("write", apply_file_filter)
    filter_combo.bind("<<ComboboxSelected>>", apply_file_filter)
    sort_combo.bind("<<ComboboxSelected>>", apply_file_filter)

    file_list_frame = ttk.Frame(window)
    file_list = ttk.Treeview(file_list_frame, columns=("filename", "last_update"), show="headings")
    file_list.heading("filename", text=file_list_headings["filename"])
    file_list.heading("last_update", text=file_list_headings["last_update"])
    file_list.column("filename", width=file_list_widths["filename"], stretch=False)
    file_list.column("last_update", width=file_list_widths["last_update"], stretch=False)
    file_list.bind('<Button-1>', lambda e: "break" if file_list.identify_region(e.x, e.y) == "separator" else None)
    y_file_list_scrollbar = tk.Scrollbar(file_list_frame, orient="vertical", command=file_list.yview)
    file_list.configure(yscrollcommand=y_file_list_scrollbar.set)
    x_file_list_scrollbar = tk.Scrollbar(file_list_frame, orient="horizontal", command=file_list.xview)
    file_list.configure(xscrollcommand=x_file_list_scrollbar.set)
    y_file_list_scrollbar.pack(side="right", fill="y")
    x_file_list_scrollbar.pack(side="bottom", fill="x")
    file_list.pack(side="left", fill="both", expand=True)
    file_list_frame.pack(side="top", fill="both", expand=True, pady=10)

    file_list.bind("<Shift-MouseWheel>", lambda e: file_list.xview_scroll(int(-1 * (e.delta / 120) * 4), "units"))
    x_file_list_scrollbar.bind("<MouseWheel>", lambda e: file_list.xview_scroll(int(-1 * (e.delta / 120) * 4), "units"))

    refresh()
###################################################################################################################
def edit_file_window(root, main_tree_refresh):
    checking_data_folder()
    config = load_config()
    file_list_headings = config["file_list"]["headings"]
    file_list_widths = config["file_list"]["widths"]
    font_size = config["font_size"]
    font_type = config["font_type"]

    def edit(event, file_name):
        if file_name:
            if not is_valid(file_name):
                messagebox.showerror("Invalid Name Detected", f"File name only contain alphabetical characters, digits, space, and underscore")
                return
            data_folder = checking_data_folder()
            file_path = data_folder/(file_name+".db")
            if file_path.exists():
                confirm = messagebox.askyesno("Confirmation", f"Do you want to edit file named {file_name}?")
                if not confirm: return
                try:
                    AppState.current_editing_file = file_path
                    print(AppState.current_editing_file)
                    main_tree_refresh()
                    refresh()
                except Exception as ERROR:
                    messagebox.showerror("❗Error❗", f"Error encountered: {ERROR}")
            else:
                messagebox.showerror("Non-existed Save Detected", f'File "{file_name}" does not exist!')
        else:
            if AppState.current_editing_file is None: return
            confirm = messagebox.askyesno("Confirmation", f"Do you want to exit editing file?")
            if not confirm: return
            try:
                AppState.current_editing_file = None
                print(AppState.current_editing_file)
                main_tree_refresh()
                refresh()
            except Exception as ERROR:
                messagebox.showerror("❗Error❗", f"Error encountered: {ERROR}")
        return

    def edit_double_clicked(event):
        tree = event.widget
        selected_item = tree.selection()
        if not selected_item: return
        row_values = tree.item(selected_item[0])['values']
        if row_values:
            edit(None, row_values[0].replace(".db", ""))
        return

    window = ttk.Toplevel(
        master=root,
        title="Edit List Window",
        size=(640, 640)
    )
    window.grab_set()

    all_files_cache = []
    def apply_file_filter(*args):
        """Hàm nâng cấp: Lọc theo cột chỉ định và Sắp xếp theo tiêu chí được chọn"""
        for item in file_list.get_children():
            file_list.delete(item)
        search_text = edit_file_name.get().strip().lower()
        selected_filter_display = filter_col_var.get()
        selected_sort = sort_var.get()
        # Xác định index cột cần lọc (0: filename, 1: last_update)
        filter_index = 0
        if selected_filter_display == file_list_headings["last_update"]:
            filter_index = 1
        # 1. Tiến hành lọc dữ liệu (Filter)
        filtered_files = []
        for item in all_files_cache:
            # item gồm: (file_name, last_update, is_editing)
            val_to_search = str(item[filter_index]).lower()
            if search_text in val_to_search:
                filtered_files.append(item)
        # 2. Tiến hành sắp xếp dữ liệu (Sort)
        if selected_sort != "Default":
            from datetime import datetime
            def parse_date(date_str):
                # Hàm hỗ trợ ép kiểu ngày tháng để sắp xếp chính xác
                for fmt in ("%d/%m/%Y %H:%M:%S", "%d/%m/%Y"):
                    try:
                        return datetime.strptime(date_str.strip(), fmt)
                    except ValueError:
                        continue
                return datetime.min

            if selected_sort == "Name (A-Z)":
                filtered_files.sort(key=lambda x: x[0].lower())
            elif selected_sort == "Name (Z-A)":
                filtered_files.sort(key=lambda x: x[0].lower(), reverse=True)
            elif selected_sort == "Date (Oldest ➔ Newest)":
                filtered_files.sort(key=lambda x: parse_date(x[1]))
            elif selected_sort == "Date (Newest ➔ Oldest)":
                filtered_files.sort(key=lambda x: parse_date(x[1]), reverse=True)
        # 3. Đổ dữ liệu đã xử lý xong lên giao diện Treeview
        file_list.tag_configure("odd", background="#1F1F1F", foreground="#FFFFFF", font=(font_type, font_size))
        file_list.tag_configure("even", background="#2F2F2F", foreground="#FFFFFF", font=(font_type, font_size))
        file_list.tag_configure("editing", background="#005A9E", foreground="#FFFFFF", font=(font_type, font_size, "bold"))
        visible_idx = 0
        for file_name, last_update, is_editing in filtered_files:
            visible_idx += 1
            if is_editing:
                tag = "editing"
            else:
                tag = "odd" if visible_idx & 1 else "even"
            file_list.insert("", "end", values=(file_name, last_update), tags=(tag,))

    def refresh():
        all_files_cache.clear()
        data_folder = checking_data_folder()
        for file in os.listdir(data_folder):
            if file.endswith(".db"):
                file_path = data_folder / file
                last_update = get_last_modified_date(file_path)
                if last_update is None:
                    continue
                is_editing = False
                if AppState.current_editing_file and Path(AppState.current_editing_file) == file_path:
                    is_editing = True
                all_files_cache.append((file, last_update, is_editing))
        apply_file_filter()

    edit_file_frame = ttk.Frame(window)
    edit_file_name = tk.StringVar()
    ttk.Label(edit_file_frame, text="Edit list:").pack(side="left", padx=5)
    edit_file_entry = ttk.Entry(edit_file_frame, textvariable=edit_file_name, width=20)
    edit_file_entry.bind('<Return>', lambda e: edit(None, edit_file_name.get().strip().strip("_")))
    edit_file_entry.pack(side="left", fill="x", expand=True, padx=5)
    ttk.Label(edit_file_frame, text="Filter by:").pack(side="left", padx=5)
    filter_col_var = tk.StringVar()
    filter_options = [file_list_headings["filename"], file_list_headings["last_update"]]
    filter_combo = ttk.Combobox(edit_file_frame, textvariable=filter_col_var, values=filter_options, state="readonly", width=12)
    filter_combo.current(0)
    filter_combo.pack(side="left", padx=5)
    ttk.Label(edit_file_frame, text="Sort by:").pack(side="left", padx=5)
    sort_var = tk.StringVar()
    sort_options = [
        "Default",
        "Name (A-Z)", "Name (Z-A)",
        "Date (Oldest ➔ Newest)", "Date (Newest ➔ Oldest)"
    ]
    sort_combo = ttk.Combobox(edit_file_frame, textvariable=sort_var, values=sort_options, state="readonly", width=18)
    sort_combo.current(0)
    sort_combo.pack(side="left", padx=5)
    edit_file_frame.pack(side="top", fill="x", pady=10, padx=5)
    edit_file_name.trace_add("write", apply_file_filter)
    filter_combo.bind("<<ComboboxSelected>>", apply_file_filter)
    sort_combo.bind("<<ComboboxSelected>>", apply_file_filter)

    file_list_frame = ttk.Frame(window)
    file_list = ttk.Treeview(file_list_frame, columns=("filename", "last_update"), show="headings")
    file_list.heading("filename", text=file_list_headings["filename"])
    file_list.heading("last_update", text=file_list_headings["last_update"])
    file_list.column("filename", width=file_list_widths["filename"], stretch=False)
    file_list.column("last_update", width=file_list_widths["last_update"], stretch=False)
    file_list.bind("<Shift-MouseWheel>", lambda e: file_list.xview_scroll(int(-1 * (e.delta / 120) * 16), "units"))
    file_list.bind('<Button-1>', lambda e: "break" if file_list.identify_region(e.x, e.y) == "separator" else None)
    file_list.bind("<Double-1>", edit_double_clicked)
    y_file_list_scrollbar = tk.Scrollbar(file_list_frame, orient="vertical", command=file_list.yview)
    file_list.configure(yscrollcommand=y_file_list_scrollbar.set)
    x_file_list_scrollbar = tk.Scrollbar(file_list_frame, orient="horizontal", command=file_list.xview)
    file_list.configure(xscrollcommand=x_file_list_scrollbar.set)
    y_file_list_scrollbar.pack(side="right", fill="y")
    x_file_list_scrollbar.pack(side="bottom", fill="x")
    file_list.pack(side="left", fill="both", expand=True)
    file_list_frame.pack(side="top", fill="both", expand=True, pady=10)

    file_list.bind("<Shift-MouseWheel>", lambda e: file_list.xview_scroll(int(-1 * (e.delta / 120) * 4), "units"))
    x_file_list_scrollbar.bind("<MouseWheel>", lambda e: file_list.xview_scroll(int(-1 * (e.delta / 120) * 4), "units"))

    refresh()
###################################################################################################################
def delete_file_window(root):
    checking_data_folder()
    config = load_config()
    file_list_headings = config["file_list"]["headings"]
    file_list_widths = config["file_list"]["widths"]
    font_size = config["font_size"]
    font_type = config["font_type"]

    def delete(event, file_name):
        if file_name:
            if not is_valid(file_name):
                messagebox.showerror("Invalid Name Detected", f"File name only contain alphabetical characters, digits, space, and underscore")
                return
            data_folder = checking_data_folder()
            file_path = data_folder/(file_name+".db")
            if file_path.exists():
                if AppState.current_editing_file==file_path:
                    messagebox.showerror("Editing File Encountered", f"Unable to delete {file_name} due to being editing")
                    return
                confirm = messagebox.askyesno("Confirmation", f"Do you want to delete file named {file_name}?")
                if not confirm: return
                try:
                    file_path.unlink()
                    refresh()
                except Exception as ERROR:
                    messagebox.showerror("❗Error❗", f"Error encountered: {ERROR}")
            else:
                messagebox.showerror("Non-existed Save Detected", f'File "{file_name}" does not exist!')
        return

    def delete_in_list(event):
        tree = event.widget
        selected_item = tree.selection()
        if not selected_item: return
        row_values = tree.item(selected_item[0])['values']
        if row_values:
            delete(None, row_values[0].replace(".db", ""))
        return

    window = ttk.Toplevel(
        master=root,
        title="Delete List Window",
        size=(640, 640)
    )
    window.grab_set()

    all_files_cache = []

    def apply_file_filter(*args):
        """Hàm nâng cấp: Lọc theo cột chỉ định và Sắp xếp theo tiêu chí được chọn"""
        for item in file_list.get_children():
            file_list.delete(item)
        search_text = delete_file_name.get().strip().lower()
        selected_filter_display = filter_col_var.get()
        selected_sort = sort_var.get()
        # Xác định index cột cần lọc (0: filename, 1: last_update)
        filter_index = 0
        if selected_filter_display == file_list_headings["last_update"]:
            filter_index = 1
        # 1. Tiến hành lọc dữ liệu (Filter)
        filtered_files = []
        for item in all_files_cache:
            # item gồm: (file_name, last_update, is_editing)
            val_to_search = str(item[filter_index]).lower()
            if search_text in val_to_search:
                filtered_files.append(item)
        # 2. Tiến hành sắp xếp dữ liệu (Sort)
        if selected_sort != "Default":
            from datetime import datetime
            def parse_date(date_str):
                # Hàm hỗ trợ ép kiểu ngày tháng để sắp xếp chính xác
                for fmt in ("%d/%m/%Y %H:%M:%S", "%d/%m/%Y"):
                    try:
                        return datetime.strptime(date_str.strip(), fmt)
                    except ValueError:
                        continue
                return datetime.min

            if selected_sort == "Name (A-Z)":
                filtered_files.sort(key=lambda x: x[0].lower())
            elif selected_sort == "Name (Z-A)":
                filtered_files.sort(key=lambda x: x[0].lower(), reverse=True)
            elif selected_sort == "Date (Oldest ➔ Newest)":
                filtered_files.sort(key=lambda x: parse_date(x[1]))
            elif selected_sort == "Date (Newest ➔ Oldest)":
                filtered_files.sort(key=lambda x: parse_date(x[1]), reverse=True)
        # 3. Đổ dữ liệu đã xử lý xong lên giao diện Treeview
        file_list.tag_configure("odd", background="#1F1F1F", foreground="#FFFFFF", font=(font_type, font_size))
        file_list.tag_configure("even", background="#2F2F2F", foreground="#FFFFFF", font=(font_type, font_size))
        file_list.tag_configure("editing", background="#005A9E", foreground="#FFFFFF", font=(font_type, font_size, "bold"))
        visible_idx = 0
        for file_name, last_update, is_editing in filtered_files:
            visible_idx += 1
            if is_editing:
                tag = "editing"
            else:
                tag = "odd" if visible_idx & 1 else "even"
            file_list.insert("", "end", values=(file_name, last_update), tags=(tag,))

    def refresh():
        all_files_cache.clear()
        data_folder = checking_data_folder()
        for file in os.listdir(data_folder):
            if file.endswith(".db"):
                file_path = data_folder / file
                last_update = get_last_modified_date(file_path)
                if last_update is None:
                    continue
                is_editing = False
                if AppState.current_editing_file and Path(AppState.current_editing_file) == file_path:
                    is_editing = True
                all_files_cache.append((file, last_update, is_editing))
        apply_file_filter()

    delete_file_frame = ttk.Frame(window)
    delete_file_name = tk.StringVar()
    ttk.Label(delete_file_frame, text="Delete list:").pack(side="left", padx=5)
    delete_file_entry = ttk.Entry(delete_file_frame, textvariable=delete_file_name, width=20)
    delete_file_entry.bind('<Return>', lambda e: delete(None, delete_file_name.get().strip().strip("_")))
    delete_file_entry.pack(side="left", fill="x", expand=True, padx=5)
    ttk.Label(delete_file_frame, text="Filter by:").pack(side="left", padx=5)
    filter_col_var = tk.StringVar()
    filter_options = [file_list_headings["filename"], file_list_headings["last_update"]]
    filter_combo = ttk.Combobox(delete_file_frame, textvariable=filter_col_var, values=filter_options, state="readonly", width=12)
    filter_combo.current(0)
    filter_combo.pack(side="left", padx=5)
    ttk.Label(delete_file_frame, text="Sort by:").pack(side="left", padx=5)
    sort_var = tk.StringVar()
    sort_options = [
        "Default",
        "Name (A-Z)", "Name (Z-A)",
        "Date (Oldest ➔ Newest)", "Date (Newest ➔ Oldest)"
    ]
    sort_combo = ttk.Combobox(delete_file_frame, textvariable=sort_var, values=sort_options, state="readonly", width=18)
    sort_combo.current(0)
    sort_combo.pack(side="left", padx=5)
    delete_file_frame.pack(side="top", fill="x", pady=10, padx=5)
    delete_file_name.trace_add("write", apply_file_filter)
    filter_combo.bind("<<ComboboxSelected>>", apply_file_filter)
    sort_combo.bind("<<ComboboxSelected>>", apply_file_filter)

    file_list_frame = ttk.Frame(window)
    file_list = ttk.Treeview(file_list_frame, columns=("filename", "last_update"), show="headings")
    file_list.heading("filename", text=file_list_headings["filename"])
    file_list.heading("last_update", text=file_list_headings["last_update"])
    file_list.column("filename", width=file_list_widths["filename"], stretch=False)
    file_list.column("last_update", width=file_list_widths["last_update"], stretch=False)
    file_list.bind("<Shift-MouseWheel>", lambda e: file_list.xview_scroll(int(-1 * (e.delta / 120) * 16), "units"))
    file_list.bind('<Button-1>', lambda e: "break" if file_list.identify_region(e.x, e.y) == "separator" else None)
    file_list.bind("<Delete>", delete_in_list)
    y_file_list_scrollbar = tk.Scrollbar(file_list_frame, orient="vertical", command=file_list.yview)
    file_list.configure(yscrollcommand=y_file_list_scrollbar.set)
    x_file_list_scrollbar = tk.Scrollbar(file_list_frame, orient="horizontal", command=file_list.xview)
    file_list.configure(xscrollcommand=x_file_list_scrollbar.set)
    y_file_list_scrollbar.pack(side="right", fill="y")
    x_file_list_scrollbar.pack(side="bottom", fill="x")
    file_list.pack(side="left", fill="both", expand=True)
    file_list_frame.pack(side="top", fill="both", expand=True, pady=10)
    refresh()