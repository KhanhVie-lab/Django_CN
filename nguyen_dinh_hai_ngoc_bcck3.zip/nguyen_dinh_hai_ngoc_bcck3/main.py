from functions.CONFIG import *
from functions.FILES import *
from functions.LISTS import *
from functions.STATINFO import *
from functions.CONFIGURATION import *
from data.state import AppState

config = load_config()
#AppState.current_editing_file = config.get["default_list"] if Path(config.get["default_list"]).exists() else None
print(AppState.current_editing_file)

window = ttk.Window(
    title="Product Manager v1.000",
    size=(900, 640),
    themename="darkly"
)

product_list_style = window.style
product_list_style.configure("Treeview",
    background="#1F1F1F",
    foreground="#FFFFFF",
    fieldbackground="#1F1F1F",
    rowheight=int(2.5 * config["font_size"]),
    gridlines="both"
)
product_list_style.configure("Treeview.Heading",
    background="#4F4F4F",
    foreground="#FFFFFF",
    rowheight=int(2.5 * config["font_size"]),
    font=(config.get("font_type", "Arial"), config.get("font_size", 14), "bold"),
    relief="flat"
)
product_list_style.map("Treeview.Heading",
    background=[('active', '#666666')]
)

product_list_headings = config["product_list"]["headings"]
product_list_widths = config["product_list"]["widths"]
all_keys = ["id", "name", "origin", "date", "count", "import_price", "export_price", "last_update"]

actions_frame = ttk.Frame(window)
actions_frame.pack(side="top", fill="x", pady=10, padx=10)
for i in range(4): actions_frame.columnconfigure(i, weight=1, uniform="equal_buttons")

file_create_button = ttk.Button(actions_frame, text="NEW LIST", command=lambda: new_file_window(window))
file_edit_button = ttk.Button(actions_frame, text="EDIT LIST", command=lambda: edit_file_window(window, refresh))
file_delete_button = ttk.Button(actions_frame, text="DELETE LIST", command=lambda: delete_file_window(window))
file_create_button.grid(row=0, column=0, sticky="ew", padx=2, pady=2)
file_edit_button.grid(row=0, column=1, sticky="ew", padx=2, pady=2)
file_delete_button.grid(row=0, column=2, sticky="ew", padx=2, pady=2)

product_insert_button = ttk.Button(actions_frame, text="IMPORT PRODUCT(s)", command=lambda: import_product_window(window, refresh))
product_update_button = ttk.Button(actions_frame, text="UPDATE PRODUCT(s)", command=lambda: update_product_window(window, refresh))
product_remove_button = ttk.Button(actions_frame, text="EXPORT PRODUCT(s)", command=lambda: export_product_window(window, refresh))
product_insert_button.grid(row=1, column=0, sticky="ew", padx=2, pady=2)
product_update_button.grid(row=1, column=1, sticky="ew", padx=2, pady=2)
product_remove_button.grid(row=1, column=2, sticky="ew", padx=2, pady=2)

statinfo_button = ttk.Button(actions_frame, text="STATS & INFO", command=lambda: stats_and_info_window(window))
config_button = ttk.Button(actions_frame, text="CONFIGURATION", command=lambda: configuration_window(window, product_list, refresh))
statinfo_button.grid(row=0, column=3, sticky="ew", padx=2, pady=2)
config_button.grid(row=1, column=3, sticky="ew", padx=2, pady=2)

search_frame = ttk.Frame(window)
ttk.Label(search_frame, text="Search:").pack(side="left", padx=5)
search_name = tk.StringVar()
search_entry = ttk.Entry(search_frame, textvariable=search_name, width=25)
search_entry.pack(side="left", fill="x", expand=True, padx=5)
ttk.Label(search_frame, text="Filter by:").pack(side="left", padx=5)
filter_col_var = tk.StringVar()
filter_options = [product_list_headings.get(k, k.capitalize()) for k in all_keys]
filter_combo = ttk.Combobox(search_frame, textvariable=filter_col_var, values=filter_options, state="readonly", width=15)
filter_combo.current(1)
filter_combo.pack(side="left", padx=5)
ttk.Label(search_frame, text="Sort by:").pack(side="left", padx=5)
sort_var = tk.StringVar()
sort_options = [
    "Default",
    "Name (A-Z)", "Name (Z-A)",
    "Count (Low ➔ High)", "Count (High ➔ Low)",
    "Import Price (Low ➔ High)", "Import Price (High ➔ Low)",
    "Export Price (Low ➔ High)", "Export Price (High ➔ Low)",
    "Date (Oldest ➔ Newest)", "Date (Newest ➔ Oldest)",
    "Last Update (Oldest ➔ Newest)", "Last Update (Newest ➔ Oldest)"
]
sort_combo = ttk.Combobox(search_frame, textvariable=sort_var, values=sort_options, state="readonly", width=18)
sort_combo.current(0)  # Mặc định giữ nguyên thứ tự gốc trong DB
sort_combo.pack(side="left", padx=5)
search_frame.pack(side="top", fill="x", pady=10, padx=10)

# Khung chứa danh bạ sản phẩm (Treeview)
product_list_frame = ttk.Frame(window)
product_list = ttk.Treeview(product_list_frame, columns=tuple(all_keys), show="headings")
for key in all_keys:
    product_list.heading(key, text=product_list_headings[key])
    product_list.column(key, width=product_list_widths[key], stretch=False)
product_list.bind("<Shift-MouseWheel>", lambda e: product_list.xview_scroll(int(-1 * (e.delta / 120) * 16), "units"))
product_list.bind('<Button-1>', lambda e: "break" if product_list.identify_region(e.x, e.y) == "separator" else None)
y_product_list_scrollbar = ttk.Scrollbar(product_list_frame, orient="vertical", command=product_list.yview)
product_list.configure(yscrollcommand=y_product_list_scrollbar.set)
x_product_list_scrollbar = ttk.Scrollbar(product_list_frame, orient="horizontal", command=product_list.xview)
product_list.configure(xscrollcommand=x_product_list_scrollbar.set)
y_product_list_scrollbar.pack(side="right", fill="y")
x_product_list_scrollbar.pack(side="bottom", fill="x")
product_list.pack(side="left", fill="both", expand=True)
product_list_frame.pack(side="top", fill="both", expand=True, pady=10)

current_products_data = []  # Bộ nhớ đệm lưu trữ dữ liệu gốc phục vụ search/sort nhanh
def apply_filter_and_sort(*args):
    """Hàm xử lý hiển thị Treeview dựa trên Search, Filter và Sort từ bộ nhớ đệm"""
    # Xóa toàn bộ dữ liệu đang hiển thị trên Treeview
    for item in product_list.get_children():
        product_list.delete(item)
    if not current_products_data:
        return
    search_text = search_name.get().strip().lower()
    selected_filter_display = filter_col_var.get()
    selected_sort = sort_var.get()
    # Tìm index của cột tương ứng với tiêu đề đang chọn để tiến hành lọc
    filter_index = 1  # Mặc định cột name (index 1)
    for idx, k in enumerate(all_keys):
        if product_list_headings.get(k, k.capitalize()) == selected_filter_display:
            filter_index = idx
            break
    # 1. Thực hiện lọc dữ liệu (Filter)
    filtered_rows = []
    for prod in current_products_data:
        val_str = str(prod[filter_index]).lower()
        if search_text in val_str:
            filtered_rows.append(prod)
    # 2. Thực hiện sắp xếp dữ liệu (Sort)
    if selected_sort != "Default":
        def parse_sort_val(prod, idx, val_type):
            val = str(prod[idx]).strip()
            try:
                if val_type == int: return int(val) if val else 0
                if val_type == float: return float(val) if val else 0.0
                if val_type == "date":
                    for fmt in ("%d/%m/%Y %H:%M:%S", "%d/%m/%Y"):
                        try:
                            return datetime.strptime(val, fmt)
                        except ValueError:
                            continue
                    return datetime.min
                return val.lower()
            except Exception:
                return 0 if val_type in (int, float) else ""
        if selected_sort == "Name (A-Z)":
            filtered_rows.sort(key=lambda p: parse_sort_val(p, 1, str))
        elif selected_sort == "Name (Z-A)":
            filtered_rows.sort(key=lambda p: parse_sort_val(p, 1, str), reverse=True)
        elif selected_sort == "Count (Low ➔ High)":
            filtered_rows.sort(key=lambda p: parse_sort_val(p, 4, int))
        elif selected_sort == "Count (High ➔ Low)":
            filtered_rows.sort(key=lambda p: parse_sort_val(p, 4, int), reverse=True)
        elif selected_sort == "Import Price (Low ➔ High)":
            filtered_rows.sort(key=lambda p: parse_sort_val(p, 5, float))
        elif selected_sort == "Import Price (High ➔ Low)":
            filtered_rows.sort(key=lambda p: parse_sort_val(p, 5, float), reverse=True)
        elif selected_sort == "Export Price (Low ➔ High)":
            filtered_rows.sort(key=lambda p: parse_sort_val(p, 6, float))
        elif selected_sort == "Export Price (High ➔ Low)":
            filtered_rows.sort(key=lambda p: parse_sort_val(p, 6, float), reverse=True)
        elif selected_sort == "Date (Oldest ➔ Newest)":
            filtered_rows.sort(key=lambda p: parse_sort_val(p, 3, "date"))
        elif selected_sort == "Date (Newest ➔ Oldest)":
            filtered_rows.sort(key=lambda p: parse_sort_val(p, 3, "date"), reverse=True)
        elif selected_sort == "Last Update (Oldest ➔ Newest)":
            filtered_rows.sort(key=lambda p: parse_sort_val(p, 7, "date"))
        elif selected_sort == "Last Update (Newest ➔ Oldest)":
            filtered_rows.sort(key=lambda p: parse_sort_val(p, 7, "date"), reverse=True)
    # 3. Đổ dữ liệu đã được lọc và sắp xếp vào Treeview
    product_list.tag_configure("odd", background="#1F1F1F", foreground="#FFFFFF")
    product_list.tag_configure("even", background="#2F2F2F", foreground="#FFFFFF")
    for i, prod in enumerate(filtered_rows, start=1):
        tag = "odd" if i & 1 else "even"
        product_list.insert("", "end", values=prod, tags=(tag,))

def refresh():
    """Hàm tải dữ liệu từ database, chỉ kích hoạt khi load file hoặc thêm/sửa/xóa sản phẩm"""
    global current_products_data
    config = load_config()
    font_t = config.get("font_type", "Arial")
    font_s = config.get("font_size", 14)
    product_list_style.configure("Treeview", rowheight=int(font_s * 2.5), font=(font_t, font_s))
    product_list_style.configure("Treeview.Heading", rowheight=int(font_s * 2.5), font=(font_t, font_s, "bold"))
    if AppState.current_editing_file is not None:
        try:
            with sqlite3.connect(AppState.current_editing_file) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT id, name, origin, date, count, import_price, export_price, last_update FROM products")
                current_products_data = cursor.fetchall()
        except Exception as e:
            print(f"Error reading database: {e}")
            current_products_data = []
        apply_filter_and_sort()
    else:
        current_products_data = []
        apply_filter_and_sort()

search_name.trace_add("write", apply_filter_and_sort)
filter_combo.bind("<<ComboboxSelected>>", apply_filter_and_sort)
sort_combo.bind("<<ComboboxSelected>>", apply_filter_and_sort)
refresh()

window.mainloop()