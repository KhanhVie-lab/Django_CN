import ttkbootstrap as ttk
import tkinter as tk
from tkinter import messagebox
window = ttk.Window()
window.title("Quản Lý Đồ Dùng Thể Thao")
window.geometry("600x600")
def them_do_dung():
    ten_do_dung = entry_input.get().strip()
    if ten_do_dung: 
        listbox.insert(tk.END, ten_do_dung)  
        entry_input.delete(0, tk.END) 
    else:
        messagebox.showwarning("Cảnh báo", "Vui lòng nhập tên đồ dùng!")
def xoa_do_dung():
    try: 
        vi_tri_duoc_chon = listbox.curselection()
        for index in reversed(vi_tri_duoc_chon):
            listbox.delete(index)
    except IndexError:
        messagebox.showwarning("Cảnh báo", "Vui lòng chọn đồ dùng cần xóa!")
item_input = ttk.Label(window, text="Nhập tên đồ dùng thể thao:", font=("Arial", 14))
item_input.pack(pady=5)
entry_input = ttk.Entry(window, font=("Arial", 16), width=35)
entry_input.pack(pady=5)
btn_them = ttk.Button(window, text="Thêm đồ dùng", command=them_do_dung)
btn_them.pack(pady=5)
lbl_list = ttk.Label(window, text="Danh sách đồ dùng:", font=("Arial", 14))
lbl_list.pack(pady=10)
listbox = tk.Listbox(
    window,
    width=35,  
    height=10,  
    font=("Arial", 18),
    selectmode=tk.MULTIPLE,
)
listbox.pack(pady=5)
du_lieu_mau = ["Quả bóng đá", "Vợt cầu lông", "Quả bóng rổ", "Áo lưới tập chiến thuật"]
for item in du_lieu_mau:
    listbox.insert(tk.END, item)
btn_xoa = ttk.Button(window, text="Xóa mục đã chọn", command=xoa_do_dung)
btn_xoa.pack(pady=10)
window.mainloop()
#Bổ sung các tính năng như sửa đồ dùng khi đã có và thêm tính năng xuất file .csv (optional)