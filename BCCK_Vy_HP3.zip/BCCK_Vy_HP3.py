import ttkbootstrap as ttk
import tkinter as tk
from tkinter import messagebox

# Khởi tạo cửa sổ
window = ttk.Window(themename="superhero")
window.title("Quản lý học sinh")
window.geometry("650x550")

# Cấu hình tỷ lệ các cột
window.columnconfigure(0, weight=1)
window.columnconfigure(1, weight=2)
window.columnconfigure(2, weight=1)

# Tiêu đề chính
label_title = ttk.Label(
    window,
    text="QUẢN LÝ HỌC SINH",
    font=("Arial", 20, "bold"),
    bootstyle="info"
)
label_title.grid(row=0, column=0, columnspan=3, pady=20)

# Nhập dữ liệu
label_name = ttk.Label(window, text="Tên học sinh:")
label_name.grid(row=1, column=0, padx=10, pady=10, sticky="e")

entry1 = ttk.Entry(window, width=30)
entry1.grid(row=1, column=1, padx=10, pady=10, sticky="w")

# Nhập dữ liệu
label_class = ttk.Label(window, text="Lớp:")
label_class.grid(row=2, column=0, padx=10, pady=10, sticky="e")

entry2 = ttk.Entry(window, width=30)
entry2.grid(row=2, column=1, padx=10, pady=10, sticky="w")

# Hiển thị chi tiết thông tin học sinh 
label_ten = ttk.Label(window, text="Tên: ")
label_ten.grid(row=1, column=2, padx=10, pady=10, sticky="w")

label_lop = ttk.Label(window, text="Lớp: ")
label_lop.grid(row=2, column=2, padx=10, pady=10, sticky="w")

# Danh sách dữ liệu mẫu
ds_hs = [
     {'ten': 'An', 'lop': '10'},
     {'ten': 'Dũng', 'lop': '7'}
]

# Tiêu đề danh sách
label_ds = ttk.Label(window, text="Danh sách học sinh", bootstyle="info", font=("Arial", 12, "bold"))
label_ds.grid(row=3, column=0, columnspan=3, pady=(20, 5))

# Listbox
listbox = tk.Listbox(window, width=40, height=10, font=("Arial", 10))
listbox.grid(row=4, column=0, columnspan=3, pady=10)

# Hàm cập nhật lại danh sách hiển thị trên giao diện
def update_listbox():
    listbox.delete(0, "end")
    for item in ds_hs:
        listbox.insert("end", f"{item['ten']}")

# Hàm làm mới
def refresh():
    entry1.delete(0, "end")
    entry2.delete(0, "end")
    label_ten.config(text="Tên:")
    label_lop.config(text="Lớp:")

# Hàm thêm
def insert():
    ten = entry1.get().strip().title()
    lop = entry2.get().strip()
    if not ten:
        messagebox.showwarning("Thông báo", "Vui lòng nhập tên học sinh") 
        return
    if not lop:
        messagebox.showwarning("Thông báo", "Vui lòng nhập lớp") 
        return
    ds_hs.append({'ten': ten, 'lop': lop})
    update_listbox()
    refresh()

# Hàm xóa
def delete():
    abc = listbox.curselection()
    if not abc:
        messagebox.showwarning("Thông báo", "Vui lòng chọn học sinh cần xóa")
        return
    del ds_hs[abc[0]]
    update_listbox()
    refresh()

# Hàm sửa
def edit():
    abc = listbox.curselection()
    if not abc:
        messagebox.showwarning("Thông báo", "Vui lòng chọn học sinh cần sửa từ danh sách")
        return
    index = abc[0]
    hoc_sinh = ds_hs[index]
    ten = entry1.get().strip().title()
    lop = entry2.get().strip()
    if not ten or not lop:
        messagebox.showwarning("Thông báo", "Vui lòng nhập đầy đủ thông tin tên và lớp để sửa")
        return
    ds_hs[abc[0]] = {'ten': ten, 'lop': lop}
    update_listbox()
    refresh()

# Hàm xử lý sự kiện trong Listbox
def on_select(event):
    abc = listbox.curselection()
    if abc:
        index = abc[0]
        hoc_sinh = ds_hs[index]
        # Cập nhật chi tiết
        label_ten.config(text=f"Tên: {hoc_sinh['ten']}")
        label_lop.config(text=f"Lớp: {hoc_sinh['lop']}")

# Sự kiện click chọn item trong Listbox
listbox.bind('<<ListboxSelect>>', on_select)

# Nút bấm
frame_buttons = ttk.Frame(window)
frame_buttons.grid(row=5, column=0, columnspan=3, pady=20)

btn_insert = ttk.Button(frame_buttons, text="Thêm", bootstyle="success", command=insert)
btn_insert.pack(side="left", padx=10)

btn_edit = ttk.Button(frame_buttons, text="Sửa", bootstyle="warning", command=edit)
btn_edit.pack(side="left", padx=10)

btn_delete = ttk.Button(frame_buttons, text="Xóa", bootstyle="danger", command=delete)
btn_delete.pack(side="left", padx=10)

btn_refresh = ttk.Button(frame_buttons, text="Làm mới", bootstyle="secondary", command=refresh)
btn_refresh.pack(side="left", padx=10)

# Hiển thị dữ liệu ban đầu và mở cửa sổ
update_listbox()
window.mainloop()