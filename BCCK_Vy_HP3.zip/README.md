## PHÂN TÍCH CHỨC NĂNG VÀ GIAO DIỆN SẢN PHẨM

Tên dự án: Ứng dụng Quản lý Học sinh (Student Management Application)
Ngôn ngữ phát triển: Python (Tkinter & Ttkbootstrap)
Người thực hiện: [Ngô Nguyễn Triệu Vy]

---

## I. TỔNG QUAN DỰ ÁN

- Mục tiêu: Xây dựng một ứng dụng máy tính (Desktop App) có giao diện trực quan, gọn nhẹ, giúp quản lý thông tin học sinh (Thêm, Sửa, Xóa, Làm mới, Xem chi tiết) một cách nhanh chóng.
- Đối tượng sử dụng: Giáo viên, quản lý lớp học hoặc nhân viên hành chính nhà trường.
- Thành phần công nghệ:
- Ngôn ngữ: Python.
  - Thư viện giao diện chính: Tkinter (Giao diện gốc) kết hợp Ttkbootstrap (Hỗ trợ giao diện hiện đại, tối ưu màu sắc theo chủ đề).
  - Chủ đề giao diện (Theme): SuperHero (Tông màu tối hiện đại, giảm mỏi mắt).

---

## II. CHI TIẾT GIAO DIỆN SẢN PHẨM (UI - USER INTERFACE)

Giao diện được thiết kế theo dạng lưới (Grid Layout) chia làm 3 cột chính nhằm tối ưu hóa không gian hiển thị trên màn hình kích thước chuẩn 650x550.

+--------------------------------------------------------+

| QUẢN LÝ HỌC SINH |
+--------------------------------------------------------+

| Tên học sinh: [__________] | Tên: [Xem chi tiết] |
| Lớp: [__________] | Lớp: [Xem chi tiết] |
+--------------------------------------------------------+

| Danh sách học sinh |
| +----------------------------------------------------+ |
| | - An | |
| | - Dũng | |
| +----------------------------------------------------+ |
+--------------------------------------------------------+

| [Thêm] [Sửa] [Xóa] [Làm mới] |
+--------------------------------------------------------+

## 1. Khu vực Tiêu đề (Header)

- Thành phần: Sử dụng ttk.Label định dạng chữ in hoa, cỡ chữ lớn (Font Arial 20 Bold).
- Phong cách: Màu xanh lục bảo (bootstyle="info"), căn giữa toàn bộ giao diện để tạo điểm nhấn nhận diện ứng dụng.

## 2. Khu vực Nhập liệu (Input Form) & Hiển thị chi tiết

- Cơ chế: Người dùng chọn một học sinh trên Listbox (thông tin tự điền vào Form), tiến hành sửa nội dung trong ô nhập, rồi ấn nút Sửa. Hệ thống sẽ tìm chính xác vị trí (index) của học sinh đó trong mảng dữ liệu để cập nhật lại thông tin mới.

## 3. Khu vực Danh sách (Data Presentation)

Thành phần: Sử dụng thành phần tk.Listbox đặt ở trung tâm giao diện.
Định dạng: Độ rộng phủ đều, chiều cao chứa tối đa 10 dòng cùng lúc, cỡ chữ rõ ràng, dễ đọc.

## 4. Khu vực Điều khiển (Action Buttons)

Hệ thống nút bấm được gom gọn vào một khối (Frame) đặt ở dưới cùng, sắp xếp theo hàng ngang, phân tách màu sắc trực quan dựa trên mức độ quan trọng:
Thêm (Insert): Màu xanh lá (success) – Thao tác tích cực.
Sửa (Edit): Màu vàng (warning) – Thao tác cần lưu ý.
Xóa (Delete): Màu đỏ (danger) – Thao tác nguy hiểm, cần cẩn trọng.
Làm mới (Refresh): Màu xám (secondary) – Thao tác phụ trợ.

## III. CHI TIẾT CHỨC NĂNG SẢN PHẨM (UX - USER EXPERIENCE)

Ứng dụng cung cấp trọn vẹn quy trình xử lý dữ liệu chuẩn CRUD (Create - Read - Update - Delete) lồng ghép các điều kiện kiểm tra lỗi (Validation):

## 1. Chức năng Hiển thị và Đồng bộ (Read)

Khởi tạo ban đầu: Ngay khi ứng dụng khởi chạy, hệ thống tự động quét mảng dữ liệu nội bộ (ds_hs) và nạp thẳng vào Listbox thông qua hàm khởi tạo dữ liệu, tránh tình trạng màn hình trống.
Xem chi tiết dữ liệu: Tích hợp tính năng lắng nghe sự kiện (<<ListboxSelect>>). Khi người dùng click chuột vào bất kỳ học sinh nào trong danh sách:
Hệ thống tự động trích xuất thông tin và điền ngược lại vào 2 ô nhập liệu.
Đồng thời hiển thị chi tiết lên vùng nhãn bên phải.

## 2. Chức năng Thêm học sinh (Create)

Cơ chế: Đọc dữ liệu từ ô nhập, tự động chuẩn hóa chữ viết hoa đầu từ (Ví dụ: nguyễn văn an → Nguyễn Văn An) và loại bỏ khoảng trắng thừa bằng hàm .strip().title().
Kiểm lỗi (Validation): Nếu người dùng bỏ trống ô "Tên" hoặc "Lớp", hệ thống sẽ chặn lại và bật hộp thoại cảnh báo (messagebox.showwarning), yêu cầu điền đầy đủ trước khi lưu.

## 3. Chức năng Chỉnh sửa thông tin (Update)

Cơ chế: Người dùng chọn một học sinh trên Listbox (thông tin tự điền vào Form), tiến hành sửa nội dung trong ô nhập, rồi ấn nút Sửa. Hệ thống sẽ tìm chính xác vị trí (index) của học sinh đó trong mảng dữ liệu để cập nhật lại thông tin mới.

## 4. Chức năng Xóa học sinh (Delete)

- Cơ chế: Xóa học sinh đang được chọn ra khỏi mảng dữ liệu và cập nhật lại giao diện Listbox.
- An toàn: Nếu chưa chọn học sinh nào trên danh sách mà đã bấm nút Xóa, ứng dụng sẽ phát cảnh báo nhắc nhở để tránh lỗi hệ thống.

## 5. Chức năng Làm mới (Reset Form)

- Cơ chế: Xóa toàn bộ ký tự đang nhập dở dang trong các ô Entry, đưa các nhãn hiển thị về trạng thái trống ban đầu, giúp người dùng nhanh chóng chuyển sang nhập liệu ca mới mà không phải xóa thủ công bằng tay.
